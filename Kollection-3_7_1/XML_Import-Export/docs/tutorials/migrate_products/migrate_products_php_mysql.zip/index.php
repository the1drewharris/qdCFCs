<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>

<body>
<p><a href="first_store/index.php">First store main page</a></p>
<p><a href="second_store/index.php">Second store main page</a></p>
<p><a href="second_store/display_feed.php">Second store feed display</a> </p>
</body>
</html>
