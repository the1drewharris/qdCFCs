/*
	Copyright (c) S.C. InterAKT Online SRL
	http://www.interakt.ro/
*/

function openIT(u,W,H,X,Y,n, tW) {
	if (window.showModalDialog) {
		var wnd = showModalDialog(u, window, "edge:sunken; status:off; unadorned:off; help:no; font-family:Verdana; font-size:10; dialogWidth:" + W + "px; dialogHeight:" + (H+30) + "px");
	} else {
		try{
			//Mozilla 1.7 sometimes gives an error if the URL does not contain the domain (BASE of the opener)
			var s = window.location.href;
			s = s.replace(/\?.*$/, '');
			s = s.replace(/\/[^\/]*$/, '/');
			u = s + u;
			var wnd = window.open(u, "_blank", "dependent=1,left=300,top=300,width="+(W+20)+",height="+(H+20));
			wnd.focus();
		}catch(e) {
			alert("There was an error while trying to open an window! Requested URL:" + u + "\r\nError message:" +e.message);
		}
	}
	return wnd;
}
function openHelpWindowIT(u,W,H,X,Y) {
	var wnd = window.open(u, "_qubHelpWindow", "resizable=yes,status=yes,toolbar=yes,menubar=yes,location=yes,scrollbars=yes,toolbar=yes,dependent=1,left=300,top=300,width="+(W+20)+",height="+(H+20));
	wnd.focus();
}
