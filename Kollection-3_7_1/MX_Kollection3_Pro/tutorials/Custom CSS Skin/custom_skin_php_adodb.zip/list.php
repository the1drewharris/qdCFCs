<?php require_once('Connections/connSendMail.php'); ?>
<?php
// Load the common classes
require_once('includes/common/KT_common.php');

// Load the required classes
require_once('includes/tfi/TFI.php');
require_once('includes/tso/TSO.php');
require_once('includes/nav/NAV.php');

// Make unified connection variable
$conn_connSendMail = new KT_connection($connSendMail, $database_connSendMail);

// Filter
$tfi_listsubscribe_sub1 = new TFI_TableFilter($conn_connSendMail, "tfi_listsubscribe_sub1");
$tfi_listsubscribe_sub1->addColumn("subscribe_sub.type_sub", "STRING_TYPE", "type_sub", "%");
$tfi_listsubscribe_sub1->addColumn("domain_dom.id_dom", "NUMERIC_TYPE", "iddom_sub", "=");
$tfi_listsubscribe_sub1->addColumn("location_loc.id_loc", "STRING_TYPE", "location_sub", "%");
$tfi_listsubscribe_sub1->addColumn("subscribe_sub.minsal_sub", "NUMERIC_TYPE", "minsal_sub", "=");
$tfi_listsubscribe_sub1->Execute();

// Sorter
$tso_listsubscribe_sub1 = new TSO_TableSorter("rssubscribe_sub1", "tso_listsubscribe_sub1");
$tso_listsubscribe_sub1->addColumn("subscribe_sub.type_sub");
$tso_listsubscribe_sub1->addColumn("domain_dom.name_dom");
$tso_listsubscribe_sub1->addColumn("location_loc.name_loc");
$tso_listsubscribe_sub1->addColumn("subscribe_sub.minsal_sub");
$tso_listsubscribe_sub1->setDefault("subscribe_sub.type_sub");
$tso_listsubscribe_sub1->Execute();

// Navigation
$nav_listsubscribe_sub1 = new NAV_Regular("nav_listsubscribe_sub1", "rssubscribe_sub1", "", $_SERVER['PHP_SELF'], 10);

mysql_select_db($database_connSendMail, $connSendMail);
$query_Recordset1 = "SELECT name_dom, id_dom FROM domain_dom ORDER BY name_dom";
$Recordset1 = mysql_query($query_Recordset1, $connSendMail) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

mysql_select_db($database_connSendMail, $connSendMail);
$query_Recordset2 = "SELECT name_loc, id_loc FROM location_loc ORDER BY name_loc";
$Recordset2 = mysql_query($query_Recordset2, $connSendMail) or die(mysql_error());
$row_Recordset2 = mysql_fetch_assoc($Recordset2);
$totalRows_Recordset2 = mysql_num_rows($Recordset2);

//NeXTenesio3 Special List Recordset
$maxRows_rssubscribe_sub1 = $_SESSION['max_rows_nav_listsubscribe_sub1'];
$pageNum_rssubscribe_sub1 = 0;
if (isset($_GET['pageNum_rssubscribe_sub1'])) {
  $pageNum_rssubscribe_sub1 = $_GET['pageNum_rssubscribe_sub1'];
}
$startRow_rssubscribe_sub1 = $pageNum_rssubscribe_sub1 * $maxRows_rssubscribe_sub1;

$NXTFilter_rssubscribe_sub1 = "1=1";
if (isset($_SESSION['filter_tfi_listsubscribe_sub1'])) {
  $NXTFilter_rssubscribe_sub1 = $_SESSION['filter_tfi_listsubscribe_sub1'];
}
$NXTSort_rssubscribe_sub1 = "subscribe_sub.type_sub";
if (isset($_SESSION['sorter_tso_listsubscribe_sub1'])) {
  $NXTSort_rssubscribe_sub1 = $_SESSION['sorter_tso_listsubscribe_sub1'];
}
mysql_select_db($database_connSendMail, $connSendMail);

$query_rssubscribe_sub1 = sprintf("SELECT subscribe_sub.type_sub, domain_dom.name_dom AS iddom_sub, location_loc.name_loc AS location_sub, subscribe_sub.minsal_sub, subscribe_sub.id_sub FROM (subscribe_sub LEFT JOIN domain_dom ON subscribe_sub.iddom_sub = domain_dom.id_dom) LEFT JOIN location_loc ON subscribe_sub.location_sub = location_loc.id_loc WHERE %s ORDER BY %s", $NXTFilter_rssubscribe_sub1, $NXTSort_rssubscribe_sub1);
$query_limit_rssubscribe_sub1 = sprintf("%s LIMIT %d, %d", $query_rssubscribe_sub1, $startRow_rssubscribe_sub1, $maxRows_rssubscribe_sub1);
$rssubscribe_sub1 = mysql_query($query_limit_rssubscribe_sub1, $connSendMail) or die(mysql_error());
$row_rssubscribe_sub1 = mysql_fetch_assoc($rssubscribe_sub1);

if (isset($_GET['totalRows_rssubscribe_sub1'])) {
  $totalRows_rssubscribe_sub1 = $_GET['totalRows_rssubscribe_sub1'];
} else {
  $all_rssubscribe_sub1 = mysql_query($query_rssubscribe_sub1);
  $totalRows_rssubscribe_sub1 = mysql_num_rows($all_rssubscribe_sub1);
}
$totalPages_rssubscribe_sub1 = ceil($totalRows_rssubscribe_sub1/$maxRows_rssubscribe_sub1)-1;
//End NeXTenesio3 Special List Recordset

$nav_listsubscribe_sub1->checkBoundries();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<HEAD><TITLE>Your Company Name</TITLE>
<META content="text/html; charset=iso-8859-1" http-equiv=Content-Type>
<SCRIPT language=JavaScript>
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</SCRIPT>

<LINK href="styles.css" rel=stylesheet type=text/css>
<META content=no http-equiv=imagetoolbar>
<META content="MSHTML 5.00.2920.0" name=GENERATOR>
<link href="includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="includes/common/js/base.js" type="text/javascript" language="javascript"></script>
<script src="includes/common/js/utility.js" type="text/javascript" language="javascript"></script>
<script src="includes/skins/style.js" type="text/javascript" language="javascript"></script>
<script src="includes/nxt/scripts/list.js" type="text/javascript" language="javascript"></script>
<script src="includes/nxt/scripts/list.js.php" type="text/javascript" language="javascript"></script>
<script type="text/javascript" language="javascript">
$NXT_LIST_SETTINGS = {
  duplicate_buttons: true,
  duplicate_navigation: true,
  row_effects: true,
  show_as_buttons: true,
  record_counter: true
}
</script>
<style type="text/css">
  /* NeXTensio3 List row settings */
  .KT_col_type_sub {width:140px; overflow:hidden;}
  .KT_col_iddom_sub {width:140px; overflow:hidden;}
  .KT_col_location_sub {width:140px; overflow:hidden;}
  .KT_col_minsal_sub {width:140px; overflow:hidden;}
</style>
</HEAD>
<BODY bgColor=#eaf0ee leftMargin=0 
onload="MM_preloadImages('btn_home_over.jpg')" 
text=#000000 topMargin=0 marginheight="0" marginwidth="0">
<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
  <TBODY>
  <TR>
    <TD width=750>
      <TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
        <TBODY>
        <TR>
          <TD><IMG height=83 src="top_01.jpg" width=750><BR><IMG 
            height=26 src="top_02.jpg" width=750></TD></TR>
        <TR>
          <TD>
            <TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
              <TBODY>
              <TR>
                <TD vAlign=top width=132><A 
                  href="index.htm" 
                  ><IMG 
                  border=0 height=20 name=Image3 src="btn_home.jpg" 
                  width=132><BR>
                </A> <A 
                  href="list.php" 
                  ><IMG 
                  border=0 height=20 name=Image6 
                  src="btn_products.jpg" width=132></A><BR>
                <A 
                  href="contact.php" 
                  ><IMG 
                  border=0 height=19 name=Image9 
                  src="btn_contact.jpg" width=132></A><BR>
                <IMG 
                  height=12 src="left_01.jpg" width=132><BR>
                <A 
                  href="index.htm#" 
                  onmouseout=MM_swapImgRestore() 
                  onmouseover="MM_swapImage('Image3','','btn_home_over.jpg',1)"></A></TD>
                <TD vAlign=top><IMG height=112 
                  src="image_main.jpg" width=618><BR><IMG height=40 
                  src="gph_pageheader.jpg" 
            width=618></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD>
    <TD background=bg_rightpage.jpg vAlign=top 
    width="100%">&nbsp;</TD></TR></TBODY></TABLE>
<TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
  <TBODY>
  <TR>
    <TD background=bg_left.jpg vAlign=top width=132><IMG 
      height=317 src="image_left.jpg" width=132></TD>
    <TD bgColor=#ffffff vAlign=top>
      <TABLE border=0 cellPadding=0 cellSpacing=15 width="100%">
        <TBODY>
        <TR>
          <TD><p> <FONT color=#666666 face="Verdana, Arial, Helvetica, sans-serif" 
            size=2><B><FONT color=#333333>
            <div class="KT_tng" id="listsubscribe_sub1">
              <h1> Subscribe
                  <?php
  $nav_listsubscribe_sub1->Prepare();
  require("includes/nav/NAV_Text_Statistics.inc.php");
?>
              </h1>
              <div class="KT_tnglist">
                <form action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>" method="post" name="form1" id="form1">
                  <div class="KT_options"> <a href="<?php echo $nav_listsubscribe_sub1->getShowAllLink(); ?>"><?php echo NXT_getResource("Show"); ?>
                    <?php 
  // Show IF Conditional region1
  if (@$_GET['show_all_nav_listsubscribe_sub1'] == 1) {
?>
                    <?php echo $_SESSION['default_max_rows_nav_listsubscribe_sub1']; ?>
                    <?php 
  // else Conditional region1
  } else { ?>
                    <?php echo NXT_getResource("all"); ?>
                    <?php } 
  // endif Conditional region1
?>
                        <?php echo NXT_getResource("records"); ?></a> &nbsp; &nbsp;
                        <?php 
  // Show IF Conditional region2
  if (@$_SESSION['has_filter_tfi_listsubscribe_sub1'] == 1) {
?>
                        <a href="<?php echo $tfi_listsubscribe_sub1->getResetFilterLink(); ?>"><?php echo NXT_getResource("Reset filter"); ?></a>
                        <?php 
  // else Conditional region2
  } else { ?>
                        <a href="<?php echo $tfi_listsubscribe_sub1->getShowFilterLink(); ?>"><?php echo NXT_getResource("Show filter"); ?></a>
                        <?php } 
  // endif Conditional region2
?>
                  </div>
                  <table cellpadding="2" cellspacing="0" class="KT_tngtable">
                    <thead>
                      <tr class="KT_row_order">
                        <th> <input type="checkbox" name="KT_selAll" id="KT_selAll"/>
                        </th>
                        <th id="type_sub" class="KT_sorter KT_col_type_sub <?php echo $tso_listsubscribe_sub1->getSortIcon('subscribe_sub.type_sub'); ?>"> <a href="<?php echo $tso_listsubscribe_sub1->getSortLink('subscribe_sub.type_sub'); ?>">Type</a> </th>
                        <th id="iddom_sub" class="KT_sorter KT_col_iddom_sub <?php echo $tso_listsubscribe_sub1->getSortIcon('domain_dom.name_dom'); ?>"> <a href="<?php echo $tso_listsubscribe_sub1->getSortLink('domain_dom.name_dom'); ?>">Iddom</a> </th>
                        <th id="location_sub" class="KT_sorter KT_col_location_sub <?php echo $tso_listsubscribe_sub1->getSortIcon('location_loc.name_loc'); ?>"> <a href="<?php echo $tso_listsubscribe_sub1->getSortLink('location_loc.name_loc'); ?>">Location</a> </th>
                        <th id="minsal_sub" class="KT_sorter KT_col_minsal_sub <?php echo $tso_listsubscribe_sub1->getSortIcon('subscribe_sub.minsal_sub'); ?>"> <a href="<?php echo $tso_listsubscribe_sub1->getSortLink('subscribe_sub.minsal_sub'); ?>">Minsal</a> </th>
                        <th>&nbsp;</th>
                      </tr>
                      <?php 
  // Show IF Conditional region3
  if (@$_SESSION['has_filter_tfi_listsubscribe_sub1'] == 1) {
?>
                      <tr class="KT_row_filter">
                        <td>&nbsp;</td>
                        <td><input type="text" name="tfi_listsubscribe_sub1_type_sub" id="tfi_listsubscribe_sub1_type_sub" value="<?php echo KT_escapeAttribute(@$_SESSION['tfi_listsubscribe_sub1_type_sub']); ?>" size="20" maxlength="255" /></td>
                        <td><select name="tfi_listsubscribe_sub1_iddom_sub" id="tfi_listsubscribe_sub1_iddom_sub">
                            <option value="" <?php if (!(strcmp("", @$_SESSION['tfi_listsubscribe_sub1_iddom_sub']))) {echo "SELECTED";} ?>><?php echo NXT_getResource("None"); ?></option>
                            <?php
do {  
?>
                            <option value="<?php echo $row_Recordset1['id_dom']?>"<?php if (!(strcmp($row_Recordset1['id_dom'], @$_SESSION['tfi_listsubscribe_sub1_iddom_sub']))) {echo "SELECTED";} ?>><?php echo $row_Recordset1['name_dom']?></option>
                            <?php
} while ($row_Recordset1 = mysql_fetch_assoc($Recordset1));
  $rows = mysql_num_rows($Recordset1);
  if($rows > 0) {
      mysql_data_seek($Recordset1, 0);
	  $row_Recordset1 = mysql_fetch_assoc($Recordset1);
  }
?>
                          </select>
                        </td>
                        <td><select name="tfi_listsubscribe_sub1_location_sub" id="tfi_listsubscribe_sub1_location_sub">
                            <option value="" <?php if (!(strcmp("", @$_SESSION['tfi_listsubscribe_sub1_location_sub']))) {echo "SELECTED";} ?>><?php echo NXT_getResource("None"); ?></option>
                            <?php
do {  
?>
                            <option value="<?php echo $row_Recordset2['id_loc']?>"<?php if (!(strcmp($row_Recordset2['id_loc'], @$_SESSION['tfi_listsubscribe_sub1_location_sub']))) {echo "SELECTED";} ?>><?php echo $row_Recordset2['name_loc']?></option>
                            <?php
} while ($row_Recordset2 = mysql_fetch_assoc($Recordset2));
  $rows = mysql_num_rows($Recordset2);
  if($rows > 0) {
      mysql_data_seek($Recordset2, 0);
	  $row_Recordset2 = mysql_fetch_assoc($Recordset2);
  }
?>
                          </select>
                        </td>
                        <td><input type="text" name="tfi_listsubscribe_sub1_minsal_sub" id="tfi_listsubscribe_sub1_minsal_sub" value="<?php echo KT_escapeAttribute(@$_SESSION['tfi_listsubscribe_sub1_minsal_sub']); ?>" size="20" maxlength="100" /></td>
                        <td><input type="submit" name="tfi_listsubscribe_sub1" value="<?php echo NXT_getResource("Filter"); ?>" /></td>
                      </tr>
                      <?php } 
  // endif Conditional region3
?>
                    </thead>
                    <tbody>
                      <?php if ($totalRows_rssubscribe_sub1 == 0) { // Show if recordset empty ?>
                      <tr>
                        <td colspan="6"><?php echo NXT_getResource("The table is empty or the filter you've selected is too restrictive."); ?></td>
                      </tr>
                      <?php } // Show if recordset empty ?>
                      <?php if ($totalRows_rssubscribe_sub1 > 0) { // Show if recordset not empty ?>
                      <?php do { ?>
                      <tr class="<?php echo @$cnt1++%2==0 ? "" : "KT_even"; ?>">
                        <td><input type="checkbox" name="kt_pk_subscribe_sub" class="id_checkbox" value="<?php echo $row_rssubscribe_sub1['id_sub']; ?>" />
                            <input type="hidden" name="id_sub" class="id_field" value="<?php echo $row_rssubscribe_sub1['id_sub']; ?>" />
                        </td>
                        <td><div class="KT_col_type_sub"><?php echo KT_FormatForList($row_rssubscribe_sub1['type_sub'], 20); ?></div></td>
                        <td><div class="KT_col_iddom_sub"><?php echo KT_FormatForList($row_rssubscribe_sub1['iddom_sub'], 20); ?></div></td>
                        <td><div class="KT_col_location_sub"><?php echo KT_FormatForList($row_rssubscribe_sub1['location_sub'], 20); ?></div></td>
                        <td><div class="KT_col_minsal_sub"><?php echo KT_FormatForList($row_rssubscribe_sub1['minsal_sub'], 20); ?></div></td>
                        <td><a class="KT_edit_link" href="form.php?id_sub=<?php echo $row_rssubscribe_sub1['id_sub']; ?>&amp;KT_back=1"><?php echo NXT_getResource("edit_one"); ?></a> <a class="KT_delete_link" href="#delete"><?php echo NXT_getResource("delete_one"); ?></a> </td>
                      </tr>
                      <?php } while ($row_rssubscribe_sub1 = mysql_fetch_assoc($rssubscribe_sub1)); ?>
                      <?php } // Show if recordset not empty ?>
                    </tbody>
                  </table>
                  <div class="KT_bottomnav">
                    <div>
                      <?php
            $nav_listsubscribe_sub1->Prepare();
            require("includes/nav/NAV_Text_Navigation.inc.php");
          ?>
                    </div>
                  </div>
                  <div class="KT_bottombuttons">
                    <div class="KT_operations"> <a class="KT_edit_op_link" href="#" onclick="nxt_list_edit_link_form(this); return false;"><?php echo NXT_getResource("edit_all"); ?></a> <a class="KT_delete_op_link" href="#" onclick="nxt_list_delete_link_form(this); return false;"><?php echo NXT_getResource("delete_all"); ?></a> </div>
                    <span>&nbsp;</span>
                    <select name="no_new" id="no_new">
                      <option value="1">1</option>
                      <option value="3">3</option>
                      <option value="6">6</option>
                    </select>
                    <a class="KT_additem_op_link" href="form.php?KT_back=1" onclick="return nxt_list_additem(this)"><?php echo NXT_getResource("add new"); ?></a> </div>
                </form>
              </div>
              <br class="clearfixplain" />
            </div>
            <p>&nbsp;</p>
            </FONT></B></FONT></TD>
        </TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
  <TBODY>
  <TR>
    <TD background=bg_bottom.jpg><IMG height=16 
      src="bottom_01.jpg" width=750></TD></TR>
  <TR>
    <TD bgColor=#70988e height=55><FONT color=#275a5a 
      face="Verdana, Arial, Helvetica, sans-serif" 
      size=1><B>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<A 
      href="index.htm#">Home</A> | 
      <A href="index.htm#">About 
      Us</A> | <A 
      href="index.htm#">Services</A> 
      | <A 
      href="index.htm#">Products</A> 
      | <A 
      href="index.htm#">Careers</A> 
      | <A href="index.htm#">News 
      &amp; Events</A> | <A 
      href="index.htm#">Contact 
      Us</A></B><BR><BR>&nbsp;&nbsp; &nbsp;Copyright � 2002 Your Company. All 
rights reserved. </FONT></TD></TR></TBODY></TABLE></BODY></HTML>
<?php
mysql_free_result($Recordset1);

mysql_free_result($Recordset2);

mysql_free_result($rssubscribe_sub1);
?>
