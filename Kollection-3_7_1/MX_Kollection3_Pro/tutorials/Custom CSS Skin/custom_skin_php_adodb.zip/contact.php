<?php require_once('Connections/connSendMail.php'); ?>
<?php
// Load the common classes
require_once('includes/common/KT_common.php');

// Load the tNG classes
require_once('includes/tng/tNG.inc.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("");

// Make unified connection variable
$conn_connSendMail = new KT_connection($connSendMail, $database_connSendMail);

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("E_mail", false, "text", "email", "", "", "");
$formValidation->addField("Phone", false, "text", "phone", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger

//start Trigger_SendEmail trigger
//remove this line if you want to edit the code by hand
function Trigger_SendEmail(&$tNG) {
   $emailObj = new tNG_Email($tNG);
  $emailObj->setFrom("{E_mail}{KT_defaultSender}");
  $emailObj->setTo("admin@mysite.com");
  $emailObj->setCC("");
  $emailObj->setBCC("");
  $emailObj->setSubject("New message received");
  //WriteContent method
   $emailObj->setContent("{Name} wrote:\n{Message}\nContact on: {Phone}\n\n");
   $emailObj->setEncoding("ISO-8859-1");
   $emailObj->setFormat("Text");
   $emailObj->setImportance("Normal");
   return $emailObj->Execute();
}
//end Trigger_SendEmail trigger

// Make a custom transaction instance
$customTransaction = new tNG_custom($conn_connSendMail);
$tNGs->addTransaction($customTransaction);
// Register triggers
$customTransaction->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Custom1");
$customTransaction->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$customTransaction->registerTrigger("END", "Trigger_Default_Redirect", 99, "index.htm");
$customTransaction->registerTrigger("AFTER", "Trigger_SendEmail", 40);
// Add columns
$customTransaction->addColumn("Name", "STRING_TYPE", "POST", "Name");
$customTransaction->addColumn("E_mail", "STRING_TYPE", "POST", "E_mail");
$customTransaction->addColumn("Phone", "STRING_TYPE", "POST", "Phone");
$customTransaction->addColumn("Message", "STRING_TYPE", "POST", "Message");
// End of custom transaction instance

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rscustom = $tNGs->getRecordset("custom");
$row_rscustom = mysql_fetch_assoc($rscustom);
$totalRows_rscustom = mysql_num_rows($rscustom);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<HEAD><TITLE>Your Company Name</TITLE>
<META content="text/html; charset=iso-8859-1" http-equiv=Content-Type>
<SCRIPT language=JavaScript>
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</SCRIPT>

<LINK href="styles.css" rel=stylesheet type=text/css>
<META content=no http-equiv=imagetoolbar>
<META content="MSHTML 5.00.2920.0" name=GENERATOR>
<link href="includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="includes/common/js/base.js" type="text/javascript" language="javascript"></script>
<script src="includes/common/js/utility.js" type="text/javascript" language="javascript"></script>
<script src="includes/skins/style.js" type="text/javascript" language="javascript"></script>
<?php echo $tNGs->displayValidationRules();?>
</HEAD>
<BODY bgColor=#eaf0ee leftMargin=0 
onload="MM_preloadImages('btn_home_over.jpg')" 
text=#000000 topMargin=0 marginheight="0" marginwidth="0">
<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
  <TBODY>
  <TR>
    <TD width=750>
      <TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
        <TBODY>
        <TR>
          <TD><IMG height=83 src="top_01.jpg" width=750><BR><IMG 
            height=26 src="top_02.jpg" width=750></TD></TR>
        <TR>
          <TD>
            <TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
              <TBODY>
              <TR>
                <TD vAlign=top width=132><A 
                  href="index.htm" 
                  ><IMG 
                  border=0 height=20 name=Image3 src="btn_home.jpg" 
                  width=132><BR>
                </A> <A 
                  href="list.php" 
                  ><IMG 
                  border=0 height=20 name=Image6 
                  src="btn_products.jpg" width=132></A><BR>
                <A 
                  href="contact.php" 
                  ><IMG 
                  border=0 height=19 name=Image9 
                  src="btn_contact.jpg" width=132></A><BR>
                <IMG 
                  height=12 src="left_01.jpg" width=132><BR>
                <A 
                  href="index.htm#" 
                  onmouseout=MM_swapImgRestore() 
                  onmouseover="MM_swapImage('Image3','','btn_home_over.jpg',1)"></A></TD>
                <TD vAlign=top><IMG height=112 
                  src="image_main.jpg" width=618><BR><IMG height=40 
                  src="gph_pageheader.jpg" 
            width=618></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD>
    <TD background=bg_rightpage.jpg vAlign=top 
    width="100%">&nbsp;</TD></TR></TBODY></TABLE>
<TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
  <TBODY>
  <TR>
    <TD background=bg_left.jpg vAlign=top width=132><IMG 
      height=317 src="image_left.jpg" width=132></TD>
    <TD bgColor=#ffffff vAlign=top>
      <TABLE border=0 cellPadding=0 cellSpacing=15 width="100%">
        <TBODY>
        <TR>
          <TD><p> <FONT color=#666666 face="Verdana, Arial, Helvetica, sans-serif" 
            size=2><B><FONT color=#333333>
            <?php
	echo $tNGs->getErrorMsg();
?>
            <form method="post" name="form1" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
              <table cellpadding="2" cellspacing="0" class="KT_tngtable">
                <tr>
                  <td class="KT_th"><label for="Name">Name:</label></td>
                  <td><input type="text" name="Name" id="Name" value="<?php echo KT_escapeAttribute($row_rscustom['Name']); ?>" size="32" />
                      <?php echo $tNGs->displayFieldHint("Name");?> <?php echo $tNGs->displayFieldError("custom", "Name"); ?> </td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="E_mail">E-mail:</label></td>
                  <td><input type="text" name="E_mail" id="E_mail" value="<?php echo KT_escapeAttribute($row_rscustom['E_mail']); ?>" size="32" />
                      <?php echo $tNGs->displayFieldHint("E_mail");?> <?php echo $tNGs->displayFieldError("custom", "E_mail"); ?> </td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="Phone">Phone:</label></td>
                  <td><input type="text" name="Phone" id="Phone" value="<?php echo KT_escapeAttribute($row_rscustom['Phone']); ?>" size="32" />
                      <?php echo $tNGs->displayFieldHint("Phone");?> <?php echo $tNGs->displayFieldError("custom", "Phone"); ?> </td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="Message">Message:</label></td>
                  <td><textarea name="Message" id="Message" cols="50" rows="5"><?php echo KT_escapeAttribute($row_rscustom['Message']); ?></textarea>
                      <?php echo $tNGs->displayFieldHint("Message");?> <?php echo $tNGs->displayFieldError("custom", "Message"); ?> </td>
                </tr>
                <tr class="KT_buttons">
                  <td colspan="2"><input type="submit" name="KT_Custom1" id="KT_Custom1" value="Insert record" />
                  </td>
                </tr>
              </table>
            </form>
            <p>&nbsp;</p>
            </FONT></B></FONT></TD>
        </TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
  <TBODY>
  <TR>
    <TD background=bg_bottom.jpg><IMG height=16 
      src="bottom_01.jpg" width=750></TD></TR>
  <TR>
    <TD bgColor=#70988e height=55><FONT color=#275a5a 
      face="Verdana, Arial, Helvetica, sans-serif" 
      size=1><B>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<A 
      href="index.htm#">Home</A> | 
      <A href="index.htm#">About 
      Us</A> | <A 
      href="index.htm#">Services</A> 
      | <A 
      href="index.htm#">Products</A> 
      | <A 
      href="index.htm#">Careers</A> 
      | <A href="index.htm#">News 
      &amp; Events</A> | <A 
      href="index.htm#">Contact 
      Us</A></B><BR><BR>&nbsp;&nbsp; &nbsp;Copyright � 2002 Your Company. All 
rights reserved. </FONT></TD></TR></TBODY></TABLE></BODY></HTML>
