<?php require_once('Connections/connSendMail.php'); ?>
<?php
// Load the common classes
require_once('includes/common/KT_common.php');

// Load the tNG classes
require_once('includes/tng/tNG.inc.php');

// Load the KT_back class
require_once('includes/nxt/KT_back.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("");

// Make unified connection variable
$conn_connSendMail = new KT_connection($connSendMail, $database_connSendMail);

// Start trigger
$formValidation = new tNG_FormValidation();
$tNGs->prepareValidation($formValidation);
// End trigger

mysql_select_db($database_connSendMail, $connSendMail);
$query_Recordset1 = "SELECT name_dom, id_dom FROM domain_dom ORDER BY name_dom";
$Recordset1 = mysql_query($query_Recordset1, $connSendMail) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

mysql_select_db($database_connSendMail, $connSendMail);
$query_Recordset2 = "SELECT name_loc, id_loc FROM location_loc ORDER BY name_loc";
$Recordset2 = mysql_query($query_Recordset2, $connSendMail) or die(mysql_error());
$row_Recordset2 = mysql_fetch_assoc($Recordset2);
$totalRows_Recordset2 = mysql_num_rows($Recordset2);

// Make an insert transaction instance
$ins_subscribe_sub = new tNG_multipleInsert($conn_connSendMail);
$tNGs->addTransaction($ins_subscribe_sub);
// Register triggers
$ins_subscribe_sub->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins_subscribe_sub->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins_subscribe_sub->registerTrigger("END", "Trigger_Default_Redirect", 99, "includes/nxt/back.php");
// Add columns
$ins_subscribe_sub->setTable("subscribe_sub");
$ins_subscribe_sub->addColumn("idusr_sub", "NUMERIC_TYPE", "POST", "idusr_sub", "{SESSION.kt_login_id}");
$ins_subscribe_sub->addColumn("type_sub", "STRING_TYPE", "POST", "type_sub");
$ins_subscribe_sub->addColumn("iddom_sub", "NUMERIC_TYPE", "POST", "iddom_sub");
$ins_subscribe_sub->addColumn("location_sub", "STRING_TYPE", "POST", "location_sub");
$ins_subscribe_sub->addColumn("minsal_sub", "NUMERIC_TYPE", "POST", "minsal_sub");
$ins_subscribe_sub->setPrimaryKey("id_sub", "NUMERIC_TYPE");

// Make an update transaction instance
$upd_subscribe_sub = new tNG_multipleUpdate($conn_connSendMail);
$tNGs->addTransaction($upd_subscribe_sub);
// Register triggers
$upd_subscribe_sub->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Update1");
$upd_subscribe_sub->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$upd_subscribe_sub->registerTrigger("END", "Trigger_Default_Redirect", 99, "includes/nxt/back.php");
// Add columns
$upd_subscribe_sub->setTable("subscribe_sub");
$upd_subscribe_sub->addColumn("idusr_sub", "NUMERIC_TYPE", "POST", "idusr_sub");
$upd_subscribe_sub->addColumn("type_sub", "STRING_TYPE", "POST", "type_sub");
$upd_subscribe_sub->addColumn("iddom_sub", "NUMERIC_TYPE", "POST", "iddom_sub");
$upd_subscribe_sub->addColumn("location_sub", "STRING_TYPE", "POST", "location_sub");
$upd_subscribe_sub->addColumn("minsal_sub", "NUMERIC_TYPE", "POST", "minsal_sub");
$upd_subscribe_sub->setPrimaryKey("id_sub", "NUMERIC_TYPE", "GET", "id_sub");

// Make an instance of the transaction object
$del_subscribe_sub = new tNG_multipleDelete($conn_connSendMail);
$tNGs->addTransaction($del_subscribe_sub);
// Register triggers
$del_subscribe_sub->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Delete1");
$del_subscribe_sub->registerTrigger("END", "Trigger_Default_Redirect", 99, "includes/nxt/back.php");
// Add columns
$del_subscribe_sub->setTable("subscribe_sub");
$del_subscribe_sub->setPrimaryKey("id_sub", "NUMERIC_TYPE", "GET", "id_sub");

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rssubscribe_sub = $tNGs->getRecordset("subscribe_sub");
$row_rssubscribe_sub = mysql_fetch_assoc($rssubscribe_sub);
$totalRows_rssubscribe_sub = mysql_num_rows($rssubscribe_sub);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<HEAD><TITLE>Your Company Name</TITLE>
<META content="text/html; charset=iso-8859-1" http-equiv=Content-Type>
<SCRIPT language=JavaScript>
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</SCRIPT>

<LINK href="styles.css" rel=stylesheet type=text/css>
<META content=no http-equiv=imagetoolbar>
<META content="MSHTML 5.00.2920.0" name=GENERATOR>
<link href="includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="includes/common/js/base.js" type="text/javascript" language="javascript"></script>
<script src="includes/common/js/utility.js" type="text/javascript" language="javascript"></script>
<script src="includes/skins/style.js" type="text/javascript" language="javascript"></script>
<?php echo $tNGs->displayValidationRules();?>
<script src="includes/nxt/scripts/form.js" type="text/javascript" language="javascript"></script>
<script src="includes/nxt/scripts/form.js.php" type="text/javascript" language="javascript"></script>
<script type="text/javascript" language="javascript">
$NXT_FORM_SETTINGS = {
  duplicate_buttons: true,
  show_as_grid: true,
  merge_down_value: true
}
</script>
</HEAD>
<BODY bgColor=#eaf0ee leftMargin=0 
onload="MM_preloadImages('btn_home_over.jpg')" 
text=#000000 topMargin=0 marginheight="0" marginwidth="0">
<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
  <TBODY>
  <TR>
    <TD width=750>
      <TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
        <TBODY>
        <TR>
          <TD><IMG height=83 src="top_01.jpg" width=750><BR><IMG 
            height=26 src="top_02.jpg" width=750></TD></TR>
        <TR>
          <TD>
            <TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
              <TBODY>
              <TR>
                <TD vAlign=top width=132><A 
                  href="index.htm" 
                  ><IMG 
                  border=0 height=20 name=Image3 src="btn_home.jpg" 
                  width=132><BR>
                </A> <A 
                  href="list.php" 
                  ><IMG 
                  border=0 height=20 name=Image6 
                  src="btn_products.jpg" width=132></A><BR>
                <A 
                  href="contact.php" 
                  ><IMG 
                  border=0 height=19 name=Image9 
                  src="btn_contact.jpg" width=132></A><BR>
                <IMG 
                  height=12 src="left_01.jpg" width=132><BR>
                <A 
                  href="index.htm#" 
                  onmouseout=MM_swapImgRestore() 
                  onmouseover="MM_swapImage('Image3','','btn_home_over.jpg',1)"></A></TD>
                <TD vAlign=top><IMG height=112 
                  src="image_main.jpg" width=618><BR><IMG height=40 
                  src="gph_pageheader.jpg" 
            width=618></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD>
    <TD background=bg_rightpage.jpg vAlign=top 
    width="100%">&nbsp;</TD></TR></TBODY></TABLE>
<TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
  <TBODY>
  <TR>
    <TD background=bg_left.jpg vAlign=top width=132><IMG 
      height=317 src="image_left.jpg" width=132></TD>
    <TD bgColor=#ffffff vAlign=top>
      <TABLE border=0 cellPadding=0 cellSpacing=15 width="100%">
        <TBODY>
        <TR>
          <TD><p>&nbsp;
              <?php
	echo $tNGs->getErrorMsg();
?>

            <div class="KT_tng">
              <h1>
                <?php 
// Show IF Conditional region1 
if (@$_GET['id_sub'] == "") {
?>
                <?php echo NXT_getResource("Insert_FH"); ?>
                <?php 
// else Conditional region1
} else { ?>
                <?php echo NXT_getResource("Update_FH"); ?>
                <?php } 
// endif Conditional region1
?>
    Subscribe </h1>
              <div class="KT_tngform">
                <form method="post" name="form1" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
                  <?php $cnt1 = 0; ?>
                  <?php do { ?>
                  <?php $cnt1++; ?>
                  <?php 
// Show IF Conditional region1 
if (@$totalRows_rssubscribe_sub > 1) {
?>
                  <h2><?php echo NXT_getResource("Record_FH"); ?> <?php echo $cnt1; ?></h2>
                  <?php } 
// endif Conditional region1
?>
                  <table cellpadding="2" cellspacing="0" class="KT_tngtable">
                    <tr>
                      <td class="KT_th"><label for="idusr_sub_<?php echo $cnt1; ?>">Idusr:</label></td>
                      <td><input type="text" name="idusr_sub_<?php echo $cnt1; ?>" id="idusr_sub_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rssubscribe_sub['idusr_sub']); ?>" size="7" />
                          <?php echo $tNGs->displayFieldHint("idusr_sub");?> <?php echo $tNGs->displayFieldError("subscribe_sub", "idusr_sub", $cnt1); ?> </td>
                    </tr>
                    <tr>
                      <td class="KT_th"><label for="type_sub_<?php echo $cnt1; ?>">Type:</label></td>
                      <td><select name="type_sub_<?php echo $cnt1; ?>" id="type_sub_<?php echo $cnt1; ?>">
                          <option value="Full-time" <?php if (!(strcmp("Full-time", KT_escapeAttribute($row_rssubscribe_sub['type_sub'])))) {echo "SELECTED";} ?>>Full-time</option>
                          <option value="Part-time" <?php if (!(strcmp("Part-time", KT_escapeAttribute($row_rssubscribe_sub['type_sub'])))) {echo "SELECTED";} ?>>Part-time</option>
                          <option value="Project-based" <?php if (!(strcmp("Project-based", KT_escapeAttribute($row_rssubscribe_sub['type_sub'])))) {echo "SELECTED";} ?>>Project-based</option>
                        </select>
                          <?php echo $tNGs->displayFieldError("subscribe_sub", "type_sub", $cnt1); ?> </td>
                    </tr>
                    <tr>
                      <td class="KT_th"><label for="iddom_sub_<?php echo $cnt1; ?>">Iddom:</label></td>
                      <td><select name="iddom_sub_<?php echo $cnt1; ?>" id="iddom_sub_<?php echo $cnt1; ?>">
                          <option value=""><?php echo NXT_getResource("Select one..."); ?></option>
                          <?php 
do {  
?>
                          <option value="<?php echo $row_Recordset1['id_dom']?>"<?php if (!(strcmp($row_Recordset1['id_dom'], $row_rssubscribe_sub['iddom_sub']))) {echo "SELECTED";} ?>><?php echo $row_Recordset1['name_dom']?></option>
                          <?php
} while ($row_Recordset1 = mysql_fetch_assoc($Recordset1));
  $rows = mysql_num_rows($Recordset1);
  if($rows > 0) {
      mysql_data_seek($Recordset1, 0);
	  $row_Recordset1 = mysql_fetch_assoc($Recordset1);
  }
?>
                        </select>
                          <?php echo $tNGs->displayFieldError("subscribe_sub", "iddom_sub", $cnt1); ?> </td>
                    </tr>
                    <tr>
                      <td class="KT_th"><label for="location_sub_<?php echo $cnt1; ?>">Location:</label></td>
                      <td><select name="location_sub_<?php echo $cnt1; ?>" id="location_sub_<?php echo $cnt1; ?>">
                          <option value=""><?php echo NXT_getResource("Select one..."); ?></option>
                          <?php 
do {  
?>
                          <option value="<?php echo $row_Recordset2['id_loc']?>"<?php if (!(strcmp($row_Recordset2['id_loc'], $row_rssubscribe_sub['location_sub']))) {echo "SELECTED";} ?>><?php echo $row_Recordset2['name_loc']?></option>
                          <?php
} while ($row_Recordset2 = mysql_fetch_assoc($Recordset2));
  $rows = mysql_num_rows($Recordset2);
  if($rows > 0) {
      mysql_data_seek($Recordset2, 0);
	  $row_Recordset2 = mysql_fetch_assoc($Recordset2);
  }
?>
                        </select>
                          <?php echo $tNGs->displayFieldError("subscribe_sub", "location_sub", $cnt1); ?> </td>
                    </tr>
                    <tr>
                      <td class="KT_th"><label for="minsal_sub_<?php echo $cnt1; ?>">Minsal:</label></td>
                      <td><input type="text" name="minsal_sub_<?php echo $cnt1; ?>" id="minsal_sub_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rssubscribe_sub['minsal_sub']); ?>" size="7" />
                          <?php echo $tNGs->displayFieldHint("minsal_sub");?> <?php echo $tNGs->displayFieldError("subscribe_sub", "minsal_sub", $cnt1); ?> </td>
                    </tr>
                  </table>
                  <input type="hidden" name="kt_pk_subscribe_sub_<?php echo $cnt1; ?>" class="id_field" value="<?php echo KT_escapeAttribute($row_rssubscribe_sub['kt_pk_subscribe_sub']); ?>" />
                  <?php } while ($row_rssubscribe_sub = mysql_fetch_assoc($rssubscribe_sub)); ?>
                  <div class="KT_bottombuttons">
                    <div>
                      <?php 
      // Show IF Conditional region1
      if (@$_GET['id_sub'] == "") {
      ?>
                      <input type="submit" name="KT_Insert1" id="KT_Insert1" value="<?php echo NXT_getResource("Insert_FB"); ?>" />
                      <?php 
      // else Conditional region1
      } else { ?>
                      <div class="KT_operations">
                        <input type="submit" name="KT_Insert1" value="<?php echo NXT_getResource("Insert as new_FB"); ?>" onclick="nxt_form_insertasnew(this, 'id_sub')" />
                      </div>
                      <input type="submit" name="KT_Update1" value="<?php echo NXT_getResource("Update_FB"); ?>" />
                      <input type="submit" name="KT_Delete1" value="<?php echo NXT_getResource("Delete_FB"); ?>" onclick="return confirm('<?php echo NXT_getResource("Are you sure?"); ?>');" />
                      <?php }
      // endif Conditional region1
      ?>
                      <input type="button" name="KT_Cancel1" value="<?php echo NXT_getResource("Cancel_FB"); ?>" onclick="return UNI_navigateCancel(event, 'includes/nxt/back.php')" />
                    </div>
                  </div>
                </form>
              </div>
              <br class="clearfixplain" />
            </div>
            <p>&nbsp;</p>
            </p>
</TD>
        </TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
  <TBODY>
  <TR>
    <TD background=bg_bottom.jpg><IMG height=16 
      src="bottom_01.jpg" width=750></TD></TR>
  <TR>
    <TD bgColor=#70988e height=55><FONT color=#275a5a 
      face="Verdana, Arial, Helvetica, sans-serif" 
      size=1><B>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<A 
      href="index.htm#">Home</A> | 
      <A href="index.htm#">About 
      Us</A> | <A 
      href="index.htm#">Services</A> 
      | <A 
      href="index.htm#">Products</A> 
      | <A 
      href="index.htm#">Careers</A> 
      | <A href="index.htm#">News 
      &amp; Events</A> | <A 
      href="index.htm#">Contact 
      Us</A></B><BR><BR>&nbsp;&nbsp; &nbsp;Copyright � 2002 Your Company. All 
rights reserved. </FONT></TD></TR></TBODY></TABLE></BODY></HTML>
<?php
mysql_free_result($Recordset1);

mysql_free_result($Recordset2);
?>
