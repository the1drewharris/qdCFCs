<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_connSendMail = "localhost";
$database_connSendMail = "database_name";
$username_connSendMail = "root";
$password_connSendMail = "";
$connSendMail = mysql_pconnect($hostname_connSendMail, $username_connSendMail, $password_connSendMail) or trigger_error(mysql_error(),E_USER_ERROR); 
?>