<?php
/*
	Copyright (c) InterAKT Online 2000-2005
*/

if (isset($_GET['KT_back'])) {
	require_once(dirname(realpath(__FILE__)). '/../common/KT_common.php');
	KT_session_start();
	
	$tmp = KT_addReplaceParam(KT_getFullUri(), 'KT_back');
	if (isset($_SERVER['HTTP_REFERER'])) {
		$backURL = $_SERVER['HTTP_REFERER'];
		$backURL = KT_addReplaceParam($backURL, '/^totalRows_.*$/i');
		KT_SessionKtBack($backURL);
	}

	if (isset($_POST['KT_Delete1'])) {
		?>
<html>
<head>
</head>
	<body>
		<form action="<?php echo ($tmp); ?>" method="POST" name="KT_backForm">
		<?php
		foreach($_POST as $key => $value) {
			if ($key == 'KT_Delete1' || strpos($key, 'kt_pk_') === 0) {
				if (get_magic_quotes_gpc()) {
					$value = stripslashes($value);
				}
		?>
			<input type="hidden" name="<?php echo $key; ?>" value="<?php echo KT_escapeAttribute($value); ?>" />
		<?php
			}
		}
		?>
		</form>
		<script>
			document.forms.KT_backForm.submit();
		</script>
	</body>
</html>
		<?php
	} else {
		KT_redir($tmp);
	}
	exit;
}
?>
