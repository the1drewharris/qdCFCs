<?php
$res = array(
'PHP_FILE_READ_ERROR' => 'File Error. Internal Error.',
'PHP_FILE_WRITE_ERROR' => 'File Error. Internal Error.',
'PHP_FILE_CREATE_ERROR' => 'File Error. Internal Error.',
'PHP_FILE_DELETE_ERROR' => 'File Error. Internal Error.',
'PHP_FILE_FOLDER_ERROR' => 'File Error: %s %s.',
'PHP_FILE_CHECK_FOLDER_ERROR' => 'File Error: %s. Internal Error.',
'PHP_FILE_READ_ERROR_D' => 'File Error. Reading File: %s.',
'PHP_FILE_WRITE_ERROR_D' => 'File Error. Writing content to file: %s.',
'PHP_FILE_CREATE_ERROR_D' => 'File Error. Creating File: %s.',
'PHP_FILE_DELETE_ERROR_D' => 'File Error. Deleting File: %s.',
'PHP_FILE_FOLDER_ERROR_D' => 'File Error: %s %s.',
'PHP_FILE_CHECK_FOLDER_ERROR_D' => 'File Error: %s. No %s permissions in %s folder.',
);
?>