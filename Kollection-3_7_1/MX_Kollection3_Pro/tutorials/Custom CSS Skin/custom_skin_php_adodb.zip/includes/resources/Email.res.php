<?php
$res = array(
'EMAIL_ERROR_SENDING' => 'Error sending e-mail.',
'PHP_EMAIL_FROM_NOT_SET' => 'Error sending e-mail. FROM field is not set.',
'EMAIL_ERROR_SENDING_D' => 'E-mail couldn\'t be sent. Error returned: %s.',
'PHP_EMAIL_FROM_NOT_SET_D' => 'Error sending email. FROM field is not set.',
);
?>