<?php
$res = array(
'SQL_ERROR' => '<strong>Error creating Dynamic Include:</strong><br/>%s<br/><strong>SQL:</strong><br/>%s<br/>',
'MISSING_FIELD' => '<strong>Error creating Dynamic Include:</strong><br/>The field \'%s\' is not in the recordset.<br/>',
);
?>