<?php
/*
	Copyright (c) InterAKT Online 2000-2005
*/

	class tNG_SetOrderField {
		var $tNG;
		var $table;
		var $field;
		var $mode;

		function tNG_SetOrderField(&$tNG) {
			$this->tNG = &$tNG;
			$this->table = $tNG->getTable();
			$this->field = 'myfield';
			$this->type = 'NUMERIC_TYPE';
			$this->mode = 'LAST';
			if (isset($_GET['kt_insert_first'])) {
				$this->mode = 'FIRST';
			}
		}

		function setTable($table) {
			$this->table = $table;
		}

		function setFieldName($field) {
			$this->field = $field;
		}

		function Execute() {
			$sql = 'SELECT MAX(' . KT_escapeFieldName($this->field) . ') + 1 AS kt_sortvalue FROM ' . $this->table;
			if ($this->mode == 'FIRST') {
				$sql = 'SELECT MIN(' . KT_escapeFieldName($this->field) . ') AS kt_sortvalue FROM ' . $this->table;
			}
			$ret = $this->tNG->connection->Execute($sql);
			if ($ret === false) {
				return new tNG_error('SET_ORDER_FIELD_SQL_ERROR', array(), array($this->tNG->connection->ErrorMsg(), $sql));
			}
			$value = $ret->Fields('kt_sortvalue');
			if ($value == '' || !is_numeric($value)) {
				$value = 1;
			}
			if ($this->mode == 'FIRST') {
				if ($value < 2) {
					$sql = 'UPDATE ' . $this->table . ' SET ' . KT_escapeFieldName($this->field) . ' = ' . KT_escapeFieldName($this->field) . ' + 1';
					$ret = $this->tNG->connection->Execute($sql);
					if ($ret === false) {
						return new tNG_error('SET_ORDER_FIELD_SQL_ERROR', array(), array($this->tNG->connection->ErrorMsg(), $sql));
					}
				} else {
					$value = $value - 1;
				}
			}
			$this->tNG->addColumn($this->field, 'NUMERIC_TYPE', 'VALUE', $value);
			return null;
		}
	}
?>
