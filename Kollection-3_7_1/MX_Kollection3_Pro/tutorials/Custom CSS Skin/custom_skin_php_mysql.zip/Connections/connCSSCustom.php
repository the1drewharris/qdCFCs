<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_connCSSCustom = "localhost";
$database_connCSSCustom = "custom_css_skin";
$username_connCSSCustom = "root";
$password_connCSSCustom = "password";
$connCSSCustom = mysql_pconnect($hostname_connCSSCustom, $username_connCSSCustom, $password_connCSSCustom) or die(mysql_error());
?>