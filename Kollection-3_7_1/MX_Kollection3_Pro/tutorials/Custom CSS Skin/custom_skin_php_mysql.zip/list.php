<?php require_once('Connections/connCSSCustom.php'); ?>
<?php
// Load the common classes
require_once('includes/common/KT_common.php');

// Load the required classes
require_once('includes/tfi/TFI.php');
require_once('includes/tso/TSO.php');
require_once('includes/nav/NAV.php');

// Make unified connection variable
$conn_connCSSCustom = new KT_connection($connCSSCustom, $database_connCSSCustom);

$currentPage = $HTTP_SERVER_VARS["PHP_SELF"];

// Filter
$tfi_listproduct_prd4 = new TFI_TableFilter($conn_connCSSCustom, "tfi_listproduct_prd4");
$tfi_listproduct_prd4->addColumn("category_ctg.id_ctg", "NUMERIC_TYPE", "idctg_prd", "=");
$tfi_listproduct_prd4->addColumn("product_prd.name_prd", "STRING_TYPE", "name_prd", "%");
$tfi_listproduct_prd4->addColumn("product_prd.price_prd", "DOUBLE_TYPE", "price_prd", "%");
$tfi_listproduct_prd4->addColumn("product_prd.description_prd", "STRING_TYPE", "description_prd", "%");
$tfi_listproduct_prd4->Execute();

// Sorter
$tso_listproduct_prd4 = new TSO_TableSorter("rsproduct_prd1", "tso_listproduct_prd4");
$tso_listproduct_prd4->addColumn("category_ctg.name_ctg");
$tso_listproduct_prd4->addColumn("product_prd.name_prd");
$tso_listproduct_prd4->addColumn("product_prd.price_prd");
$tso_listproduct_prd4->addColumn("product_prd.description_prd");
$tso_listproduct_prd4->setDefault("product_prd.idctg_prd");
$tso_listproduct_prd4->Execute();

// Navigation
$nav_listproduct_prd4 = new NAV_Regular("nav_listproduct_prd4", "rsproduct_prd1", "", $_SERVER['PHP_SELF'], true, 10);

mysql_select_db($database_connCSSCustom, $connCSSCustom);
$query_Recordset1 = "SELECT name_ctg, id_ctg FROM category_ctg ORDER BY name_ctg";
$Recordset1 = mysql_query($query_Recordset1, $connCSSCustom) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

//NeXTenesio3 Special List Recordset
$maxRows_rsproduct_prd1 = $_SESSION['max_rows_nav_listproduct_prd4'];
$pageNum_rsproduct_prd1 = 0;
if (isset($_GET['pageNum_rsproduct_prd1'])) {
  $pageNum_rsproduct_prd1 = $_GET['pageNum_rsproduct_prd1'];
}
$startRow_rsproduct_prd1 = $pageNum_rsproduct_prd1 * $maxRows_rsproduct_prd1;

$NXTFilter_rsproduct_prd1 = "1=1";
if (isset($_SESSION['filter_tfi_listproduct_prd4'])) {
  $NXTFilter_rsproduct_prd1 = $_SESSION['filter_tfi_listproduct_prd4'];
}
$NXTSort_rsproduct_prd1 = "product_prd.idctg_prd";
if (isset($_SESSION['sorter_tso_listproduct_prd4'])) {
  $NXTSort_rsproduct_prd1 = $_SESSION['sorter_tso_listproduct_prd4'];
}
mysql_select_db($database_connCSSCustom, $connCSSCustom);

$query_rsproduct_prd1 = sprintf("SELECT category_ctg.name_ctg AS idctg_prd, product_prd.name_prd, product_prd.price_prd, product_prd.description_prd, product_prd.id_prd FROM product_prd LEFT JOIN category_ctg ON product_prd.idctg_prd = category_ctg.id_ctg WHERE %s ORDER BY %s", $NXTFilter_rsproduct_prd1, $NXTSort_rsproduct_prd1);
$query_limit_rsproduct_prd1 = sprintf("%s LIMIT %d, %d", $query_rsproduct_prd1, $startRow_rsproduct_prd1, $maxRows_rsproduct_prd1);
$rsproduct_prd1 = mysql_query($query_limit_rsproduct_prd1, $connCSSCustom) or die(mysql_error());
$row_rsproduct_prd1 = mysql_fetch_assoc($rsproduct_prd1);

if (isset($_GET['totalRows_rsproduct_prd1'])) {
  $totalRows_rsproduct_prd1 = $_GET['totalRows_rsproduct_prd1'];
} else {
  $all_rsproduct_prd1 = mysql_query($query_rsproduct_prd1);
  $totalRows_rsproduct_prd1 = mysql_num_rows($all_rsproduct_prd1);
}
$totalPages_rsproduct_prd1 = ceil($totalRows_rsproduct_prd1/$maxRows_rsproduct_prd1)-1;
//End NeXTenesio3 Special List Recordset
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html><HEAD><TITLE>Your Company Name</TITLE>
<META content="text/html; charset=iso-8859-1" http-equiv=Content-Type>
<SCRIPT language=JavaScript>
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</SCRIPT>

<LINK href="styles.css" rel=stylesheet type=text/css>
<META content=no http-equiv=imagetoolbar>
<META content="MSHTML 5.00.2920.0" name=GENERATOR>
<link href="includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="includes/common/js/base.js" type="text/javascript" language="javascript"></script>
<script src="includes/common/js/utility.js" type="text/javascript" language="javascript"></script>
<script src="includes/skins/style.js" type="text/javascript" language="javascript"></script>
<script src="includes/nxt/scripts/list.js" type="text/javascript" language="javascript"></script>
<script src="includes/nxt/scripts/list.js.php" type="text/javascript" language="javascript"></script>
<script type="text/javascript" language="javascript">
$NXT_LIST_SETTINGS = {
  duplicate_buttons: true,
  duplicate_navigation: true,
  row_effects: true,
  show_as_buttons: true,
  record_counter: true
}
</script>
<style type="text/css">
  /* NeXTensio3 List row settings */
  .KT_col_idctg_prd {width:140px; overflow:hidden;}
  .KT_col_name_prd {width:140px; overflow:hidden;}
  .KT_col_price_prd {width:140px; overflow:hidden;}
  .KT_col_description_prd {width:140px; overflow:hidden;}
</style>
</HEAD>
<BODY bgColor=#eaf0ee leftMargin=0 

<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
  <TBODY>
  <TR>
    <TD width=750>
      <TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
        <TBODY>
        <TR>
          <TD><IMG height=83 src="top_01.jpg" width=750><BR><IMG 
            height=26 src="top_02.jpg" width=750></TD></TR>
        <TR>
          <TD>
            <TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
              <TBODY>
              <TR>
                <TD vAlign=top width=132><A 
                  href="index.htm" 
                  ><IMG 
                  border=0 height=20 name=Image3 src="btn_home.jpg" 
                  width=132><BR>
                </A>
                <A 
                  href="index.htm#" 
                  ><IMG 
                  border=0 height=20 name=Image6 
                  src="btn_products.jpg" width=132></A><BR>                
                <A 
                  href="contact.php" 
                  ><IMG 
                  border=0 height=19 name=Image9 
                  src="btn_contact.jpg" width=132></A><BR>
                <IMG 
                  height=12 src="left_01.jpg" width=132><BR><A 
                  href="index.htm#" 
                  ></A></TD>
                <TD vAlign=top><IMG height=112 
                  src="image_main.jpg" width=618><BR><IMG height=40 
                  src="gph_pageheader.jpg" 
            width=618></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD>
    <TD background=bg_rightpage.jpg vAlign=top 
    width="100%">&nbsp;</TD></TR></TBODY></TABLE>
<TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
  <TBODY>
  <TR>
    <TD background=bg_left.jpg vAlign=top width=132><IMG 
      height=317 src="image_left.jpg" width=132></TD>
    <TD bgColor=#ffffff vAlign=top>
      <TABLE border=0 cellPadding=0 cellSpacing=15 width="100%">
        <TBODY>
        <TR>
          <TD><b><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">
            <div class="KT_tng" id="listproduct_prd4">
                  <h1> Product
                      <?php
  $nav_listproduct_prd4->Prepare();
  require("includes/nav/NAV_Text_Statistics.inc.php");
?>
                  </h1>
                  <div class="KT_tnglist">
                    <form method="post" name="form1" id="form1" style="">
                      <div class="KT_options"> <a href="<?php echo $nav_listproduct_prd4->getShowAllLink(); ?>"><?php echo NXT_getResource("Show"); ?>
                        <?php 
  // Show IF Conditional region1
  if (@$_GET['show_all_nav_listproduct_prd4'] == 1) {
?>
                        <?php echo $_SESSION['default_max_rows_nav_listproduct_prd4']; ?>
                        <?php 
  // else Conditional region1
  } else { ?>
                        <?php echo NXT_getResource("all"); ?>
                        <?php } 
  // endif Conditional region1
?>
                            <?php echo NXT_getResource("records"); ?></a>
                          <?php 
  // Show IF Conditional region2
  if (@$_SESSION['has_filter_tfi_listproduct_prd4'] == 1) {
?>
                          <a href="<?php echo $tfi_listproduct_prd4->getResetFilterLink(); ?>"><?php echo NXT_getResource("Reset filter"); ?></a>
                          <?php 
  // else Conditional region2
  } else { ?>
                          <a href="<?php echo $tfi_listproduct_prd4->getShowFilterLink(); ?>"><?php echo NXT_getResource("Show filter"); ?></a>
                          <?php } 
  // endif Conditional region2
?>
                      </div>
                      <table cellpadding="2" cellspacing="0" class="KT_tngtable">
                        <thead>
                          <tr class="KT_row_order">
                            <th>
                              <input type="checkbox" name="KT_selAll" id="KT_selAll"/>
                            </th>
                            <th id="idctg_prd" class="KT_sorter <?php echo $tso_listproduct_prd4->getSortIcon('category_ctg.name_ctg'); ?>"> <a href="<?php echo $tso_listproduct_prd4->getSortLink('category_ctg.name_ctg'); ?>">Category:</a> </th>
                            <th id="name_prd" class="KT_sorter <?php echo $tso_listproduct_prd4->getSortIcon('product_prd.name_prd'); ?>"> <a href="<?php echo $tso_listproduct_prd4->getSortLink('product_prd.name_prd'); ?>">Name:</a> </th>
                            <th id="price_prd" class="KT_sorter <?php echo $tso_listproduct_prd4->getSortIcon('product_prd.price_prd'); ?>"> <a href="<?php echo $tso_listproduct_prd4->getSortLink('product_prd.price_prd'); ?>">Price:</a> </th>
                            <th id="description_prd" class="KT_sorter <?php echo $tso_listproduct_prd4->getSortIcon('product_prd.description_prd'); ?>"> <a href="<?php echo $tso_listproduct_prd4->getSortLink('product_prd.description_prd'); ?>">Description:</a> </th>
                            <th>&nbsp;</th>
                          </tr>
                          <?php 
  // Show IF Conditional region3
  if (@$_SESSION['has_filter_tfi_listproduct_prd4'] == 1) {
?>
                          <tr class="KT_row_filter">
                            <td><input type="submit" name="tfi_listproduct_prd4" value="Filter" />
                            </td>
                            <td>
                              <select name="tfi_listproduct_prd4_idctg_prd" id="tfi_listproduct_prd4_idctg_prd">
                                <option value="" <?php if (!(strcmp("", @$_SESSION['tfi_listproduct_prd4_idctg_prd']))) {echo "SELECTED";} ?>><?php echo NXT_getResource("None"); ?></option>
                                <?php
do {  
?>
                                <option value="<?php echo $row_Recordset1['id_ctg']?>"<?php if (!(strcmp($row_Recordset1['id_ctg'], @$_SESSION['tfi_listproduct_prd4_idctg_prd']))) {echo "SELECTED";} ?>><?php echo $row_Recordset1['name_ctg']?></option>
                                <?php
} while ($row_Recordset1 = mysql_fetch_assoc($Recordset1));
  $rows = mysql_num_rows($Recordset1);
  if($rows > 0) {
      mysql_data_seek($Recordset1, 0);
	  $row_Recordset1 = mysql_fetch_assoc($Recordset1);
  }
?>
                              </select>
                            </td>
                            <td><input type="text" name="tfi_listproduct_prd4_name_prd" id="tfi_listproduct_prd4_name_prd" value="<?php echo KT_escapeAttribute(@$_SESSION['tfi_listproduct_prd4_name_prd']); ?>" size="10" maxlength="200" />
                            </td>
                            <td><input type="text" name="tfi_listproduct_prd4_price_prd" id="tfi_listproduct_prd4_price_prd" value="<?php echo KT_escapeAttribute(@$_SESSION['tfi_listproduct_prd4_price_prd']); ?>" size="10" maxlength="100" />
                            </td>
                            <td><input type="text" name="tfi_listproduct_prd4_description_prd" id="tfi_listproduct_prd4_description_prd" value="<?php echo KT_escapeAttribute(@$_SESSION['tfi_listproduct_prd4_description_prd']); ?>" size="10" maxlength="100" />
                            </td>
                            <td>&nbsp;</td>
                          </tr>
                          <?php } 
  // endif Conditional region3
?>
                        </thead>
                        <tbody>
                          <?php if ($totalRows_rsproduct_prd1 == 0) { // Show if recordset empty ?>
                          <tr>
                            <td colspan="7"><?php echo NXT_getResource("The table is empty or the filter you've selected is too restrictive."); ?></td>
                          </tr>
                          <?php } // Show if recordset empty ?>
                          <?php if ($totalRows_rsproduct_prd1 > 0) { // Show if recordset not empty ?>
                          <?php do { ?>
                          <tr class="<?php echo @$cnt1++%2==0 ? "" : "KT_even"; ?>">
                            <td>
                              <input type="checkbox" name="kt_pk_product_prd" class="id_checkbox" value="<?php echo $row_rsproduct_prd1['id_prd']; ?>" />
                              <input type="hidden" name="id_prd" class="id_field" value="<?php echo $row_rsproduct_prd1['id_prd']; ?>" />
                            </td>
                            <td>
                              <div class="KT_col_idctg_prd"><?php echo KT_FormatForList($row_rsproduct_prd1['idctg_prd'], 20); ?></div>
                            </td>
                            <td>
                              <div class="KT_col_name_prd"><?php echo KT_FormatForList($row_rsproduct_prd1['name_prd'], 20); ?></div>
                            </td>
                            <td>
                              <div class="KT_col_price_prd"><?php echo KT_FormatForList($row_rsproduct_prd1['price_prd'], 20); ?></div>
                            </td>
                            <td>
                              <div class="KT_col_description_prd"><?php echo KT_FormatForList($row_rsproduct_prd1['description_prd'], 20); ?></div>
                            </td>
                            <td> <a class="KT_edit_link" href="form.php?id_prd=<?php echo $row_rsproduct_prd1['id_prd']; ?>&amp;KT_back=1"><?php echo NXT_getResource("edit_one"); ?></a> <a class="KT_delete_link" href="#delete"><?php echo NXT_getResource("delete_one"); ?></a> </td>
                          </tr>
                          <?php } while ($row_rsproduct_prd1 = mysql_fetch_assoc($rsproduct_prd1)); ?>
                          <?php } // Show if recordset not empty ?>
                        </tbody>
                      </table>
                      <div class="KT_bottomnav">
                        <div>
                          <?php
            $nav_listproduct_prd4->Prepare();
            require("includes/nav/NAV_Text_Navigation.inc.php");
          ?>
                        </div>
                      </div>
                      <div class="KT_bottombuttons">
                        <div class="KT_operations"> <a class="KT_edit_op_link" href="#" onclick="nxt_list_edit_link_form(this); return false;"><?php echo NXT_getResource("edit_all"); ?></a> <a class="KT_delete_op_link" href="#" onclick="nxt_list_delete_link_form(this); return false;"><?php echo NXT_getResource("delete_all"); ?></a> </div>
                        <select name="no_new" id="no_new">
                          <option value="1">1</option>
                          <option value="3">3</option>
                          <option value="6">6</option>
                        </select>
                        <a class="KT_additem_op_link" href="form.php?KT_back=1" onclick="return nxt_list_additem(this)"><?php echo NXT_getResource("add new"); ?></a> </div>
                    </form>
                  </div>
                </div>
                <p class="clearfix">&nbsp;</p>
          </font></b></TD>
        </TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
  <TBODY>
  <TR>
    <TD background=bg_bottom.jpg><IMG height=16 
      src="bottom_01.jpg" width=750></TD></TR>
  <TR>
    <TD bgColor=#70988e height=55><FONT color=#275a5a 
      face="Verdana, Arial, Helvetica, sans-serif" 
      size=1><B>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<A 
      href="index.htm#">Home</A> | 
      <A href="index.htm#">About 
      Us</A> | <A 
      href="index.htm#">Services</A> 
      | <A 
      href="index.htm#">Products</A> 
      | <A 
      href="index.htm#">Careers</A> 
      | <A href="index.htm#">News 
      &amp; Events</A> | <A 
      href="index.htm#">Contact 
      Us</A></B><BR><BR>&nbsp;&nbsp; &nbsp;Copyright � 2002 Your Company. All 
      rights reserved. </FONT></TD></TR></TBODY></TABLE></BODY></HTML>
<?php
mysql_free_result($Recordset1);

mysql_free_result($rsproduct_prd1);
?>
