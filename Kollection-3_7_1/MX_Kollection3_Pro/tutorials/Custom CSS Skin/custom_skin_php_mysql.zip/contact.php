<?php require_once('Connections/connCSSCustom.php'); ?>
<?php
// Load the common classes
require_once('includes/common/KT_common.php');

// Load the common classes
require_once('includes/common/KT_common.php');

// Load the tNG classes
require_once('includes/tng/tNG.inc.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("");

// Make unified connection variable
$conn_connCSSCustom = new KT_connection($connCSSCustom, $database_connCSSCustom);

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("Name", true, "text", "", "", "", "");
$formValidation->addField("E_mail", true, "text", "email", "", "", "");
$formValidation->addField("Phone", true, "text", "phone", "", "", "");
$formValidation->addField("Message", true, "text", "", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger

//start Trigger_SendEmail trigger
//remove this line if you want to edit the code by hand
function Trigger_SendEmail(&$tNG) {
   $emailObj = new tNG_Email($tNG);
  $emailObj->setFrom("{E_mail}");
  $emailObj->setTo("civascu@interaktonline.com");
  $emailObj->setCC("");
  $emailObj->setBCC("");
  $emailObj->setSubject("New site message");
  //WriteContent method
   $emailObj->setContent("{Name} wrote:\n{Message}\nPhone number: {Phone}");
   $emailObj->setEncoding("ISO-8859-1");
   $emailObj->setFormat("Text");
   $emailObj->setImportance("Normal");
   return $emailObj->Execute();
}
//end Trigger_SendEmail trigger

// Make a custom transaction instance
$customTransaction = new tNG_custom($conn_connCSSCustom);
$tNGs->addTransaction($customTransaction);
// Register triggers
$customTransaction->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Custom1");
$customTransaction->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$customTransaction->registerTrigger("END", "Trigger_Default_Redirect", 99, "thankyou.htm");
$customTransaction->registerTrigger("AFTER", "Trigger_SendEmail", 40);
// Add columns
$customTransaction->addColumn("Name", "STRING_TYPE", "POST", "Name");
$customTransaction->addColumn("E_mail", "STRING_TYPE", "POST", "E_mail");
$customTransaction->addColumn("Phone", "STRING_TYPE", "POST", "Phone");
$customTransaction->addColumn("Message", "STRING_TYPE", "POST", "Message");
// End of custom transaction instance

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rscustom = $tNGs->getRecordset("custom");
$row_rscustom = mysql_fetch_assoc($rscustom);
$totalRows_rscustom = mysql_num_rows($rscustom);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<HEAD><TITLE>Your Company Name</TITLE>
<META content="text/html; charset=iso-8859-1" http-equiv=Content-Type>
<LINK href="styles.css" rel=stylesheet type=text/css>
<META content=no http-equiv=imagetoolbar>
<META content="MSHTML 5.00.2920.0" name=GENERATOR>
<link href="includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="includes/common/js/base.js" type="text/javascript" language="javascript"></script>
<script src="includes/common/js/utility.js" type="text/javascript" language="javascript"></script>
<script src="includes/skins/style.js" type="text/javascript" language="javascript"></script>
<?php echo $tNGs->displayValidationRules();?>

</HEAD>
<BODY bgColor=#eaf0ee leftMargin=0 
onload="MM_preloadImages('btn_home_over.jpg','btn_news_over.jpg')" 
text=#000000 topMargin=0 marginheight="0" marginwidth="0">	
<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
  <TBODY>
  <TR>
    <TD width=750>
      <TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
        <TBODY>
        <TR>
          <TD><IMG height=83 src="top_01.jpg" width=750><BR><IMG 
            height=26 src="top_02.jpg" width=750></TD></TR>
        <TR>
          <TD>
            <TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
              <TBODY>
              <TR>
                <TD vAlign=top width=132><A 
                  href="index.htm" 
                  ><IMG 
                  border=0 height=20 name=Image3 src="btn_home.jpg" 
                  width=132><BR>
                </A> <A 
                  href="list.php" 
                  ><IMG 
                  border=0 height=20 name=Image6 
                  src="btn_products.jpg" width=132></A><BR>
                <A 
                  href="contact.php" 
                  ><IMG 
                  border=0 height=19 name=Image9 
                  src="btn_contact.jpg" width=132></A><BR>
                <IMG 
                  height=12 src="left_01.jpg" width=132><BR>
                  <A 
                  href="index.htm#" 
                  onmouseout=MM_swapImgRestore() 
                  onmouseover="MM_swapImage('Image3','','btn_home_over.jpg',1)"></A></TD>
                <TD vAlign=top><IMG height=112 
                  src="image_main.jpg" width=618><BR><IMG height=40 
                  src="gph_pageheader.jpg" 
            width=618></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD>
    <TD background=bg_rightpage.jpg vAlign=top 
    width="100%">&nbsp;</TD></TR></TBODY></TABLE>
<TABLE border=0 cellPadding=0 cellSpacing=0 width=750>
  <TBODY>
  <TR>
    <TD background=bg_left.jpg vAlign=top width=132><IMG 
      height=317 src="image_left.jpg" width=132></TD>
    <TD bgColor=#ffffff vAlign=top>
      <TABLE border=0 cellPadding=0 cellSpacing=15 width="100%">
        <TBODY>
        <TR>
          <TD><FONT color=#666666 face="Verdana, Arial, Helvetica, sans-serif" 
            size=2>
            <?php
	echo $tNGs->getErrorMsg();
?>
</FONT>
            <form method="post" name="form1" action="">
              <table cellpadding="2" cellspacing="0" class="KT_tngtable">
                <tr>
                  <td class="KT_th"><a href="index.htm#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image8','','btn_news_over.jpg',1)">
                    <label for="Name">Name:</label>
                  </a></td>
                  <td><a href="index.htm#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image8','','btn_news_over.jpg',1)">
                    <input type="text" name="Name" id="Name" value="<?php echo KT_escapeAttribute($row_rscustom['Name']); ?>" size="32" />
                    <?php echo $tNGs->displayFieldHint("Name");?> <?php echo $tNGs->displayFieldError("custom", "Name"); ?> </a></td>
                </tr>
                <tr>
                  <td class="KT_th"><a href="index.htm#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image8','','btn_news_over.jpg',1)">
                    <label for="E_mail">E-mail:</label>
                  </a></td>
                  <td><a href="index.htm#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image8','','btn_news_over.jpg',1)">
                    <input type="text" name="E_mail" id="E_mail" value="<?php echo KT_escapeAttribute($row_rscustom['E_mail']); ?>" size="32" />
                    <?php echo $tNGs->displayFieldHint("E_mail");?> <?php echo $tNGs->displayFieldError("custom", "E_mail"); ?> </a></td>
                </tr>
                <tr>
                  <td class="KT_th"><a href="index.htm#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image8','','btn_news_over.jpg',1)">
                    <label for="Phone">Phone:</label>
                  </a></td>
                  <td><a href="index.htm#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image8','','btn_news_over.jpg',1)">
                    <input type="text" name="Phone" id="Phone" value="<?php echo KT_escapeAttribute($row_rscustom['Phone']); ?>" size="32" />
                    <?php echo $tNGs->displayFieldHint("Phone");?> <?php echo $tNGs->displayFieldError("custom", "Phone"); ?> </a></td>
                </tr>
                <tr>
                  <td class="KT_th"><a href="index.htm#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image8','','btn_news_over.jpg',1)">
                    <label for="Message">Message:</label>
                  </a></td>
                  <td><a href="index.htm#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image8','','btn_news_over.jpg',1)">
                    <textarea name="Message" id="Message" cols="50" rows="5"><?php echo KT_escapeAttribute($row_rscustom['Message']); ?></textarea>
                    <?php echo $tNGs->displayFieldHint("Message");?> <?php echo $tNGs->displayFieldError("custom", "Message"); ?> </a></td>
                </tr>
                <tr class="KT_buttons">
                  <td colspan="2"><a href="index.htm#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image8','','btn_news_over.jpg',1)">
                    <input type="submit" name="KT_Custom1" id="KT_Custom1" value="Insert record" />
                  </a></td>
                </tr>
              </table>
            </form>
            <p>&nbsp;</p></TD>
        </TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
  <TBODY>
  <TR>
    <TD background=bg_bottom.jpg><IMG height=16 
      src="bottom_01.jpg" width=750></TD></TR>
  <TR>
    <TD bgColor=#70988e height=55><FONT color=#275a5a 
      face="Verdana, Arial, Helvetica, sans-serif" 
      size=1><B>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<A 
      href="index.htm#">Home</A> | 
      <A href="index.htm#">About 
      Us</A> | <A 
      href="index.htm#">Services</A> 
      | <A 
      href="index.htm#">Products</A> 
      | <A 
      href="index.htm#">Careers</A> 
      | <A href="index.htm#">News 
      &amp; Events</A> | <A 
      href="index.htm#">Contact 
      Us</A></B><BR><BR>&nbsp;&nbsp; &nbsp;Copyright � 2002 Your Company. All 
rights reserved. </FONT></TD></TR></TBODY></TABLE></BODY></HTML>
