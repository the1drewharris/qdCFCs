<?php
// Copyright 2001-2004 Interakt Online. All rights reserved.
include_once('fileBrowser.inc.php');
@session_start();
$CurrentPath = isset($_GET["path"])?$_GET["path"]:"";
KTML_security();//TODO : schimba apelul sa ia un parametru cu cheia unica

$FolderEditor = new KT_folder();
$ImageEditor = new KT_image();
$FileUpload = new KT_fileUpload();

$FileBrowserFolder = KT_realpath(realpath(__FILE__)."/../", false);

define("THUMBNAILS_FOLDER", $MinimalPath . ".thumbnails/");
define("UNDO_FOLDER", $MinimalPath . ".undo/");
define("EDITOR_FOLDER", $MinimalPath . ".editor/");

$UndoFileName = UNDO_FOLDER . "undo";

$KtmlAllowedExtensions = array("bmp","gif","xbm","png","jpeg","jpg","jpe","jfif","tiff","tif");
global $KtmlRejectedDirectories;
$KtmlRejectedDirectories = array('/\.svn/i', '/\.thumbnails/i', '/\.undo/i', '/\.editor/i');

if(!$BelowTheRootTest || !$SessionTest) {
	echo "error\r\nYou have supplied an invalid path!!!";
	exit;
}

$action = isset($_GET["action"]) ? $_GET["action"] : "";

$path = KTML_get_var("path", "", "G", "");
$FolderEditor->createFolder(KT_realpath(THUMBNAILS_FOLDER . $path));

$file = KTML_get_var("file", "", "G", "");
switch ($action) {
	case "listfolders": {
		$dirs = fileBrowser_getDirs($RealPath);
		echo ".\r\n";
		echo "..\r\n";
		if (count($dirs) > 0) {
			echo implode($dirs, "\r\n");
			echo "\r\n";
		}
		break;
	}
	case "getfileinfo": {
		$fsb = fileBrowser_fileSizeBytes($RealPath . $file);
		list ($imgWidth, $imgHeight) = $ImageEditor->imagesize($RealPath . $file);
		echo "success\r\n".$fsb."\t".$imgWidth."\t".$imgHeight;
		break;
	}
	case "listfiles": {
		$FolderEditor = new KT_folder();
		$FolderEditor->createFolder(KT_realpath(THUMBNAILS_FOLDER . $path));
		$files = fileBrowser_getFiles($RealPath, $path);
		if (count($files) > 0) {
			echo implode($files, "\r\n");
		}
		echo "\r\n";
		break;
	}
	case "makefolder": {
		$NewFolderName = isset($_GET["newFolderName"])?urldecode($_GET["newFolderName"]):"";
		if (preg_match('/\/|\\|\*|:|"|<|>|\./i', $NewFolderName)) {
			echo "error\r\n";
			echo "Invalid folder name";
			exit;
		}
		$RealPath .= $NewFolderName;
		if(is_dir($RealPath)){
			echo "error\r\n";
			echo "Folder already exists $RealPath .";
		}else{
			$FolderEditor = new KT_folder();
			$FolderEditor->createFolder(KT_realpath($RealPath));
			if ($FolderEditor->hasError()){
				echo "error\r\n";
				echo "Could not create folder";
			} else {
				echo "success";
			}
		}
		break;
	}
	case "removefolder": {
		$FolderEditor = new KT_folder();
		$FolderEditor->deleteFolder($RealPath);
		if ($FolderEditor->hasError()) {
			$arr = $FolderEditor->getError();
			echo "error\r\n".$arr[1];
		} else {
			$FolderEditor = new KT_folder();
			$FolderEditor->deleteFolder(THUMBNAILS_FOLDER . $path);
			echo "success";
		}
		break;
	}
	case "removefile": {
		$RealPath .= $file;
		if(@file_exists($RealPath)){
			if(@is_file($RealPath) || @is_link($RealPath)){
				if (@unlink($RealPath)) {
					echo "success";
					@unlink(THUMBNAILS_FOLDER . $path . $file);
					@unlink(THUMBNAILS_FOLDER . $path . "medium_".$file);
				} else { echo "error\r\nCould not delete file."; }
			} else { echo "error\r\nNot a file or link."; }
		} else { echo "error\r\nFile does not exist. [$workFolder]"; }
		break;
	}
	case "createpreview": {
		$prefix = KTML_get_var("prefix", "", "G", "");
		$width = KTML_get_var("width", "", "G", "");

		if ($file == "") {
			echo "error\r\nThe file parameter was not specified!";
			exit;
		}
		$hasPreview = is_file(THUMBNAILS_FOLDER . $path . $prefix . $file);
		if (!$hasPreview) {
			$ImageEditor = new KT_image();
			$ImageEditor->resize($RealPath . $file, THUMBNAILS_FOLDER . $path, $prefix . $file, $width, '', true);
			if ($ImageEditor->hasError()) {
				echo "error\r\nResize failed!";
				exit;
			}
		}
		echo "success";
		break;
	}
	case 'testforfile': {
		if (file_exists($RealPath.$file)) {
			echo "success";
		} else {
			echo "error\r\n File does not exist";
		}
		exit;
	}
	default:
		echo "error\r\nUnknown action";
}


?>
