<?php

	$KT_AFO_uploadErrorMsg = '<strong>File not found:</strong> <br />%s<br /><strong>Please upload the includes/ folder to the testing server.</strong> <br /><a href="http://www.interaktonline.com/error/?error=upload_includes" onclick="return confirm(\'Some data will be submitted to InterAKT. Do you want to continue?\');" target="KTDebugger_0">Online troubleshooter</a>';
	$KT_AFO_uploadFileList = array('Afo.functions.inc.php', '../resources/KT_Resources.php');

	for ($KT_AFO_i=0;$KT_AFO_i<sizeof($KT_AFO_uploadFileList);$KT_AFO_i++) {
		$KT_AFO_uploadFileName = dirname(realpath(__FILE__)). '/' . $KT_AFO_uploadFileList[$KT_AFO_i];
		if (file_exists($KT_AFO_uploadFileName)) {
			require_once($KT_AFO_uploadFileName);
		} else {
			die(sprintf($KT_AFO_uploadErrorMsg,$KT_AFO_uploadFileList[$KT_AFO_i]));
		}
	}

?>

