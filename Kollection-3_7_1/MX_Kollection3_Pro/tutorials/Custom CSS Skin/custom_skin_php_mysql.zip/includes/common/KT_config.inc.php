<?php
// Array definitions

// Start Variable definitions
  $KT_db_date_format = "yyyy-mm-dd";
  $KT_db_time_format = "HH:mm:ss";
  $KT_screen_date_format = "m/d/yy";
  $KT_screen_time_format = "h:mm:ss t";
// End Variable definitions
?>
