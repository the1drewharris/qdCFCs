<?php
/*
	Copyright (c) InterAKT Online 2000-2004
*/

/**
 * This class is the "login" class.
 * @access public
 */
class tNG_login extends tNG_custom {
	var $loginType = 'form';
	/**
	 * Constructor. Sets the connection, the database name and other default values.
	 * Also sets the transaction type.
	 * @param object KT_Connection &$connection the connection object
	 * @access public
	 */
	function tNG_login(&$connection) {
		parent::tNG_custom($connection);
		$this->transactionType = '_login';
		//TODO: Check that $GLOBALS['tNG_login_config']['table'] really exist. If not, die w/error
		if ($GLOBALS['tNG_login_config']['table'] == "") {
			die("Internal error. Please configure your login table in InterAKT Control Panel > Login Settings.");
		}
		if ($GLOBALS['tNG_login_config']['pk_field'] == "" || $GLOBALS['tNG_login_config']['pk_type'] == "") {
			die("Internal error. Please configure your login primary key in InterAKT Control Panel > Login Settings.");
		}
		
		$this->setPrimaryKey($GLOBALS['tNG_login_config']['pk_field'], $GLOBALS['tNG_login_config']['pk_type']);
		$this->exportRecordset = true;
		$this->registerTrigger("AFTER", "Trigger_Login_CheckLogin", -10);
		if ($GLOBALS['tNG_login_config']['activation_field'] != "") {
			$this->registerTrigger("AFTER", "Trigger_Login_CheckUserActive", -8);
		}
		$this->registerTrigger("AFTER", "Trigger_Login_AddDynamicFields", -6);
		$this->registerTrigger("AFTER", "Trigger_Login_SaveDataToSession", -4);
		$this->registerTrigger("AFTER", "Trigger_Login_AutoLogin", -2);
	}
	
	function setLoginType($loginType) {
		$this->loginType = $loginType;
	}
	
	/**
	 * Prepares the custom SQL query to be executed
	 * @access protected
	 */
	function prepareSQL() {
		tNG_log::log('tNG_login', 'prepareSQL', 'begin');
		
		$table = $GLOBALS['tNG_login_config']['table'];
		$pk_column = $this->getPrimaryKey();
		$user_column = $GLOBALS['tNG_login_config']['user_field'];
		$password_column = $GLOBALS['tNG_login_config']['password_field'];

		$sql = "SELECT *, ". KT_escapeFieldName($pk_column) ." AS kt_login_id, ". KT_escapeFieldName($user_column) ." AS kt_login_user, ". KT_escapeFieldName($password_column)." AS kt_login_password FROM ". $table;
		if ($this->loginType == 'form') {
			$sql.= " WHERE ".KT_escapeFieldName($user_column). "={kt_login_user}";
		} else {
			$sql.= " WHERE ".KT_escapeFieldName($pk_column). "={kt_login_id}";
		}
		
		$sql = tNG_DynamicData($sql, $this, "SQL");
		$this->setSQL($sql);
		tNG_log::log('tNG_login', 'prepareSQL', 'end');
		return null;
	}
	
	/**
	 * Get the local recordset associated to this transaction
	 * @return object resource Recordset resource
	 * @access protected
	 */
	function getLocalRecordset() {
		tNG_log::log('tNG_login', 'getLocalRecordset');
		$fakeArr = array();
		$tmpArr = $this->columns;
		foreach($tmpArr as $colName=>$colDetails) {
			$tmpVal = KT_escapeForSql($colDetails['value'], $colDetails['type'], true);
			$fakeArr[$colName] = $tmpVal;
		}
		return $this->getFakeRecordset($fakeArr);
	}

	
}
?>
