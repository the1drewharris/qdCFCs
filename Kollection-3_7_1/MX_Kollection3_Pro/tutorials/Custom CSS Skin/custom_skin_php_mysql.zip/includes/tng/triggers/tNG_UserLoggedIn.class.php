<?php
class tNG_UserLoggedIn {
	var $levels = array();
	var $connection;
	
	function tNG_UserLoggedIn(&$connection) {
		$this->connection = &$connection;
	}
	
	function addLevel($level) {
		array_push($this->levels, $level);
	}
	
	function Execute() {
		tNG_cookieLogin($this->connection);
		// access denied defaults to "redirect_failed" specified in Login Config
		$grantAccess = false;
	
		if (isset($_SESSION['kt_login_user'])) {
			if (count($this->levels) > 0) {
				if (isset($_SESSION['kt_login_level'])) {
					if (in_array($_SESSION['kt_login_level'], $this->levels) ) {
						$grantAccess = true;
					}
				}
			} else { 
				// no levels are required for this page access
				// the user is logged in, so grant the access
				$grantAccess = true;
			}
		}
		return $grantAccess;
	}
}

?>
