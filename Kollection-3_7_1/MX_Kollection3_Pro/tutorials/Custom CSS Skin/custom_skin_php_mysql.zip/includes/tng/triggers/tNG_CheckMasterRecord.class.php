<?php

	class tNG_CheckMasterRecord extends tNG_CheckTableField {
		var $fkField = '';
		function tNG_CheckMasterRecord(&$tNG) {
			parent::tNG_CheckTableField($tNG);
		}

		function setFkFieldName($field) {
			$this->fkField = $field;
			$this->setFieldType($this->tNG->getColumnType($field));
			$this->setFieldValue($this->tNG->getColumnValue($field));
		}

		function Execute() {
			$this->errorIfExists(false);
			$err = parent::Execute();
			if ($err != NULL) {
				$useSavedData = false;
				if (in_array($this->tNG->transactionType, array('_delete', '_multipleDelete'))) {
					$useSavedData = true;
				}			
				$this->errorMsg = tNG_DynamicData($this->errorMsg, $this->tNG, '', $useSavedData);
				
				if ($this->fkField != '' && $this->tNG->columns[$this->fkField]['method']=='POST') {
					// set field error to $this->errorMsg
					// set user error to $message
					$err = new tNG_error('TRIGGER_MESSAGE__CHECK_MASTER_RECORD', array(), array());
					$err->setFieldError($this->fkField, '%s', array($this->errorMsg));
				} else {
					// don't set field error
					// set composed message as user error
					$err = new tNG_error('TRIGGER_MESSAGE__CHECK_MASTER_RECORD', array(), array());
					$err->addDetails('%s', array($this->errorMsg), array(''));
				}
			}
			return $err;
		}
	}
?>
