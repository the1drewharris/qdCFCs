<?php
/*
	class to handle Logout
*/

class tNG_Logout {
	var $logoutType = 'load';
	var $pageRedirect = "";

	function setLogoutType($logoutType = 'load') {
		$this->logoutType = $logoutType;
	}
	
	function setPageRedirect($pageRedirect) {
		$this->pageRedirect = KT_makeIncludedURL($pageRedirect);
	}
	
	function unsetAll() {
		unset($_SESSION['kt_login_id']);
		unset($_SESSION['kt_login_level']);
		unset($_SESSION['kt_login_user']);
	
		unset($_SESSION['KT_denied_pageuri']);
		unset($_SESSION['KT_denied_pagelevels']);	
		
		// remove cookies
		$config_arr = session_get_cookie_params();
		$cookie_path = $config_arr['path'];
		setcookie("kt_login_id", "" , time() - 3600, $cookie_path);
		setcookie("kt_login_test", "" , time() - 3600, $cookie_path);
		unset($_COOKIE['kt_login_id']);
		unset($_COOKIE['kt_login_test']);
		if (is_array($GLOBALS['tNG_login_config_session'])) {
			$ses_arr = $GLOBALS['tNG_login_config_session'];
			foreach ($ses_arr as $ses_name => $ses_value) {
				unset($_SESSION[$ses_name]);
			}
		}	
	}
	
	function Execute() {
		// remove sessions
		if (strtolower($this->logoutType) == "load") {
			$this->unsetAll();
			if($this->pageRedirect != "") {
				KT_redir ($this->pageRedirect);
			}	
		}
		else {
			if(isset($_GET['KT_logout_now']) && $_GET['KT_logout_now'] == "true"){
				$this->unsetAll();
				if($this->pageRedirect != "") {
					KT_redir ($this->pageRedirect);
				}else {
					// redirect to self - after removing value for KT_logout_now
					KT_redir (KT_addReplaceParam($_SERVER['REQUEST_URI'], 'KT_logout_now', ''));
				}	
			}
		}	
	}
	
	function getLogoutLink() {
		return KT_addReplaceParam($_SERVER['REQUEST_URI'], 'KT_logout_now', 'true');
	}
}

?>
