<?php
	class tNG_ThrowError {
		var $tNG;
		var $errorMsg;
		var $fieldErrorMsg;
		var $field;

		function tNG_ThrowError(&$tNG) {
			$this->tNG = &$tNG;
			$this->errorMsg = '';
			$this->field = '';
			$this->fieldErrorMsg = '';
		}

		function setErrorMsg($errorMsg) {
			$this->errorMsg = $errorMsg;
		}

		function setFieldErrorMsg($fieldErrorMsg) {
			$this->fieldErrorMsg = $fieldErrorMsg;
		}

		function setField($field) {
			$this->field = $field;
		}

		function Execute() {
			$useSavedData = false;
			if (in_array($this->tNG->transactionType, array('_delete', '_multipleDelete'))) {
				$useSavedData = true;
			}

			$this->errorMsg = tNG_DynamicData($this->errorMsg, $this->tNG, '', $useSavedData);
			$this->fieldErrorMsg = tNG_DynamicData($this->fieldErrorMsg, $this->tNG, '', $useSavedData);

			if (isset($this->tNG->columns[$this->field]) && $this->tNG->columns[$this->field]['method'] == 'POST') {
				// set field error to $this->errorMsg
				// set user error to $message
				$err = new tNG_error('%s', array($this->errorMsg), array(''));
				$err->setFieldError($this->field, '%s', array($this->fieldErrorMsg));				
			} else {
				// don't set field error
				// set composed message as user error
				$err = new tNG_error('%s', array($this->errorMsg), array(''));
				$err->addDetails('%s', array($this->fieldErrorMsg), array(''));
			}
			return $err;
		}
	}
?>
