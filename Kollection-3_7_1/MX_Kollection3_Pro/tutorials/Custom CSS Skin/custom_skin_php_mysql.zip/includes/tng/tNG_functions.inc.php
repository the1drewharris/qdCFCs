<?php

function tNG_downloadDynamicFile($siteRootPath, $dynamicFolder, $dynamicFileName) {
	$ret = "";
	if ($dynamicFileName != "") {
		$folder = tNG_DynamicData($dynamicFolder,null);
		$fileName = tNG_DynamicData($dynamicFileName,null);
		$folder = KT_realpath($folder);
		$absPath = KT_realpath($folder . $fileName, false);
		
		$now = time();
		if (isset($_SESSION['tNG']['download'])) {	
			if (is_array($_SESSION['tNG']['download'])) {
				foreach($_SESSION['tNG']['download'] as $tmpId => $detail) {
					if ($detail['time'] < $now - 60*5) {
						unset($_SESSION['tNG']['download'][$tmpId]);
					}
				}
			} else {
				$_SESSION['tNG']['download'] = array();
			}
			
		} else {
			$_SESSION['tNG']['download'] = array();
		}
		
		$uniqueId = md5($absPath);
		if (!isset($_SESSION['tNG']['download'][$uniqueId])) {
			$downloadInfo = array();
			$downloadInfo['realPath'] = $absPath;
			$downloadInfo['fileName'] = $fileName;
			$downloadInfo['time'] = $now;
			$_SESSION['tNG']['download'][$uniqueId] = $downloadInfo;
		}
		if ($siteRootPath != "") {
			$siteRootPath = str_replace("\\", "/", $siteRootPath);
			if (substr($siteRootPath, strlen($siteRootPath)-1) != '/') {
				$siteRootPath .= '/';
			}
		}
		$ret = $siteRootPath."includes/tng/pub/tNG_download.php?id=".rawurlencode($uniqueId);
	}
	return $ret;
}
/**
 * Checks if a file specified by the dynamic folder and dynamic file expressions exists
 * @param string $dynamicFolder the folder name (may be a tNG dynamic expression)
 * @param string $dynamicFileName the file name (may be a tNG dynamic expression)
 * @return boolean
 *         true if the file exists, 
 *         false if the file does not exist
 */
function tNG_fileExists($dynamicFolder, $dynamicFileName) {
	$ret = false;
	if ($dynamicFileName != "") {
		$folder = tNG_DynamicData($dynamicFolder,null);
		$fileName = tNG_DynamicData($dynamicFileName,null);
		if ($fileName != "") {
			$folder = KT_realpath($folder);
			$relPath = KT_realpath($folder . $fileName, false);
			$ret = file_exists($relPath);
		}
	}
	return $ret;
}

/**
 * Creates and returns the image relative path using the dynamic folder and dynamic file expressions
 * @param string $dynamicFolder the folder name (may be a tNG dynamic expression)
 * @param string $dynamicFileName the file name (may be a tNG dynamic expression)
 * @return string
 *         the relative path to the image file, 
 *         empty if the dynamicFileName is empty
 */
function tNG_showDynamicImage($siteRootPath, $dynamicFolder, $dynamicFileName) {
	if ($dynamicFileName != "") {
		$folder = tNG_DynamicData($dynamicFolder,null);
		$fileName = tNG_DynamicData($dynamicFileName,null);
		$folder = str_replace("\\", "/", $folder);
		if (substr($folder, strlen($folder)-1) != '/') {
			$folder .= '/';
		}
		$relPath = $folder.$fileName;
		if (!file_exists($relPath)) {
			$relPath = $siteRootPath."includes/tng/styles/img_not_found.gif";
		} else {
			clearstatcache();
			// get current file permissions
			$decperms = @fileperms($relPath);
			if ($decperms !== false) {
				$octalperms = decoct($decperms);
				$perms = substr($octalperms,-3);
				// if no read right
				if ( substr($perms,-1) < 4 ) {
					$perms = octdec($perms);
					$perms = $perms | 4;
					$res = @chmod($relPath, $perms);
					// if setting permissions failed
					if ($res === false) {
							$relPath = $siteRootPath."includes/tng/styles/img_not_found.gif";
					}
				}
			}
		}
	} else {
		$relPath = $siteRootPath."includes/tng/styles/img_not_found.gif";
	}
	return $relPath;
}

/**
 * Creates and returns the relative path of an image thumbnail using the dynamic folder and dynamic file expressions
 * @param string $dynamicFolder the folder name (may be a tNG dynamic expression)
 * @param string $dynamicFileName the file name (may be a tNG dynamic expression)
 * @param integer $width the width of the thumbnail to be created
 * @param integer $height the width of the thumbnail to be created
 * @param boolean $proportional specify if the thumbnail preserve the proportions of the original image
 * @return string
 *         the relative path to the image file, 
 *         empty if the dynamicFileName is empty or if the thumbnail could ne be created
 */
function tNG_showDynamicThumbnail($siteRootPath, $dynamicFolder, $dynamicFileName, $width, $height, $proportional) {
	$relPath = "";
	if ($dynamicFileName != "") {
		$folder = tNG_DynamicData($dynamicFolder,null);
		$fileName = tNG_DynamicData($dynamicFileName,null);
		$folder = str_replace("\\", "/", $folder);
		if (substr($folder, strlen($folder)-1) != '/') {
			$folder .= '/';
		}
		$relPath = $folder.$fileName;
		$path_info = KT_pathinfo($fileName);
		$thumbnailFolder = $folder .'thumbnails/';
		$thumbnailName = $path_info['filename'].'_'.(int)$width.'x'.(int)$height.(isset($path_info['extension'])?'.'.$path_info['extension']:'');
		$relPath = $thumbnailFolder . $thumbnailName;
		if (!file_exists($thumbnailFolder.$thumbnailName)) {
			if ($fileName != '' && file_exists($folder.$fileName)) {
				$image = new KT_image();
				$image->setPreferedLib($GLOBALS['tNG_prefered_image_lib']);
				$image->addCommand($GLOBALS['tNG_prefered_imagemagick_path']);
				$image->resize(KT_realpath($folder . $fileName, false), KT_realpath($thumbnailFolder), $thumbnailName, (int)$width, (int)$height, $proportional);
				if ($image->hasError()) {
					$errorArr = $image->getError();
					if ($GLOBALS['tNG_debug_mode'] == 'DEVELOPMENT') {
						$errMsg = $errorArr[1];
						$relPath = $siteRootPath."includes/tng/styles/cannot_thumbnail.gif\" />".$errMsg."<img src=\"".$siteRootPath."includes/tng/styles/cannot_thumbnail.gif";
					} else {
						$relPath = $siteRootPath."includes/tng/styles/cannot_thumbnail.gif";
					}
				}
			} else {
				$relPath = $siteRootPath."includes/tng/styles/img_not_found.gif";
			}
		}
	}
	return $relPath;
}

/**
 * Checks if the value for a given expression changed
 * @param string $fieldName unique identifier of the expression to be checked for change
 * @param any $fieldValue the value of the expression to be checked
 * @return boolean
 *         true if the field value has changed
 *         false if not
 */
function tNG_fieldHasChanged($fieldName, $fieldValue) {
	static $values;
	$retVal = false;
	if (!isset($values[$fieldName]) || $values[$fieldName] != $fieldValue) {
		$retVal = true;
	}
	$values[$fieldName] = $fieldValue;
	return $retVal;
}

function tNG_getReplacementsFromMessage(&$string) {
	$replacements = array();

	if (preg_match_all('/\{([\w\d\.\s\(\)]+)\}/', $string, $matches)) {
		if (isset($matches[1]) && is_array($matches[1])) {
			$replacements = $matches[1];
		}
	}

	return $replacements;
}

function tNG_getEscapedStringFromMessage(&$string) {
	$newmessage = preg_replace('/\{[^\s}]+\}/', '%s', $string);
	return $newmessage;
}

/**
* Function tNG_DynamicData
* @param string $expression The expression to be evaluated
* @param object or null $tNG The tNG context in which the expression is evaluated
* @param string $escapeMethod The string escape method for the evaluated values (rawurlencode and SQL)
* @param booolean $useSavedData Weather to use the current tNG data or the saved values
* @param array $extraParams Extra expression parameters passed when for evaluation (of form $key => $value; any encounter of key will be replaced with its value)
*/
function tNG_DynamicData($expression, $tNG, $escapeMethod = '', $useSavedData = false, $extraParams = array(), $errorIfNotFound = true) {
	$PB = '{';
	$PE = '}';

	// DynamicData functions - use this to define more functions
	KT_getInternalTimeFormat();
	$date_now = KT_convertDate(date('Y-m-d'), "yyyy-mm-dd", $GLOBALS['KT_screen_date_format']);
	$date_dt_now = KT_convertDate(date('Y-m-d H:i:s'), "yyyy-mm-dd HH:ii:ss", $GLOBALS['KT_screen_date_format'].' ' .$GLOBALS['KT_screen_time_format_internal']);
	$date_t_now = KT_convertDate(date('H:i:s'), "HH:ii:ss", $GLOBALS['KT_screen_time_format_internal']);
	$dynamicDataFunctions = array(
		'NOW()' => $date_now,
		'now()' => $date_now,
		'NOW' => $date_now,
		'now' => $date_now,
		'NOW_DT()' => $date_dt_now,
		'now_dt()' => $date_dt_now,
		'NOW_DT' => $date_dt_now,
		'now_dt' => $date_dt_now,
		'NOW_T()' => $date_t_now,
		'now_t()' => $date_t_now,
		'NOW_T' => $date_t_now,
		'now_t' => $date_t_now
	);

	$placeholdersArr = tNG_getReplacementsFromMessage($expression);

	$replacementsArr = array();

	switch ($escapeMethod) {
		case 'rawurlencode' :
			break;
		case 'expression' :
			break;			
		case 'SQL' :
			if (!isset($tNG)) {
				$escapeMethod = false;
			}
			break;
		default :
			$escapeMethod = false;
			break;
	}

	if ($useSavedData !== true) {
		$useSavedData = false;
	}

	foreach ($placeholdersArr as $placeholder) {
		if (in_array($placeholder, array_keys($extraParams))) {
			// extra params have priority 1
			$placeholderType = 'tNG_DDextra';
			$placeholderName = $placeholder;
		} else {
			// functions have priority 2
			if (in_array($placeholder, array_keys($dynamicDataFunctions))) {
				$placeholderType = 'tNG_DDfunction';
				$placeholderName = $placeholder;
			}	else {
				$ptpos = strpos($placeholder, '.');
				if (!$ptpos) {
					// tng field
					if (isset($tNG)) {
						// attached to a tng, replace field with value
						$placeholderType = 'tNG_tNGfield';
						$placeholderName = $placeholder;
					} else {
						// no tng, leave as is
						$placeholderType = 'tNG_tNGfieldLater';
						$placeholderName = $placeholder;
					}
				} else {
					$placeholderType = substr($placeholder, 0, $ptpos);
					$placeholderName = substr($placeholder, $ptpos + 1);
				}
			}
		}
		$placeholder = $PB . $placeholder . $PE;
		switch (strtolower($placeholderType)) {
			case 'tng_ddfunction' :
				$replacementsArr[$placeholder] = $dynamicDataFunctions[$placeholderName];
				break;
			case 'tng_ddextra' :
				$replacementsArr[$placeholder] = $extraParams[$placeholderName];
				break;
			case 'tng_tngfield' :
				if ($useSavedData) {
					$placeholderValue = $tNG->getSavedValue($placeholderName);
				} else {
					if (isset($tNG->columns[$placeholderName]) || $placeholderName == $tNG->getPrimaryKey()) {
						$placeholderValue = $tNG->getColumnValue($placeholderName);
						$placeholderType = $tNG->getColumnType($placeholderName);
					} else {
						if ($errorIfNotFound == true) {
							die('tNG_DynamicData:<br />Column ' . $placeholderName . ' is not part of the current transaction.');
						} else {
							$placeholderValue = $placeholder;
						}
					}
					if ($escapeMethod == 'SQL') {
						$placeholderValue = KT_escapeForSql($placeholderValue, $placeholderType);
					}
				}
				$replacementsArr[$placeholder] = $placeholderValue;
				break;
			case 'tng_tngfieldlater':
				break;
			case 'get':
				$myPlaceholderName = $placeholderName;
				if (isset($tNG)) {
					if (isset($tNG->multipleIdx)) {
						$myPlaceholderName .= "_".$tNG->multipleIdx;
					}
				}
				$replacementsArr[$placeholder] = tNG_getRealValue("GET",$myPlaceholderName);
				if (!isset($replacementsArr[$placeholder])) {
					$replacementsArr[$placeholder] = tNG_getRealValue("GET",$placeholderName);
				}
				break;
			case 'post':
				$myPlaceholderName = $placeholderName;
				if (isset($tNG)) {
					if (isset($tNG->multipleIdx)) {
						$myPlaceholderName .= "_".$tNG->multipleIdx;
					}
				}
				$replacementsArr[$placeholder] = tNG_getRealValue("POST",$myPlaceholderName);
				if (!isset($replacementsArr[$placeholder])) {
					$replacementsArr[$placeholder] = tNG_getRealValue("POST",$placeholderName);
				}
				break;
			case 'cookie':
				$replacementsArr[$placeholder] = tNG_getRealValue("COOKIE",$placeholderName);
				break;
			case 'session':
				KT_session_start();
				$replacementsArr[$placeholder] = tNG_getRealValue("SESSION",$placeholderName);
				break;
			case 'globals':
				$replacementsArr[$placeholder] = tNG_getRealValue("GLOBALS",$placeholderName);
				break;
			case 'request':
				$replacementsArr[$placeholder] = tNG_getRealValue("GLOBALS",$placeholderName);
				break;
			case 'application':
				// CF only
				break;
			default :
				// recordset
				if (isset($GLOBALS[$placeholderType])) {
					$rs = $GLOBALS[$placeholderType];
					if (is_resource($rs)) {
						$placeholderValue = $GLOBALS["row_".$placeholderType][$placeholderName];
					} elseif (is_object($rs)) {
						$placeholderValue = $rs->Fields($placeholderName);
					} else {
						break;
					}
				} else {
					$placeholderValue = $placeholder;
				}
				$replacementsArr[$placeholder] = $placeholderValue;
				break;
		}
	}

	reset($replacementsArr);
	if ($escapeMethod == 'rawurlencode') {
		if (!array_key_exists ("{kt_login_redirect}", $replacementsArr)) {
			$replacementsArr = array_map($escapeMethod, $replacementsArr);
		}
	} elseif ($escapeMethod == 'expression') {
		$replacementsArr = array_map('KT_escapeExpression', $replacementsArr);
	}
	$newexpression = str_replace(array_keys($replacementsArr), array_values($replacementsArr), $expression);
	/*if ($escapeMethod == 'expression') {
		echo $newexpression."\n<br/>\n";
	}*/
	return $newexpression;
}

function tNG_stripslashes($value, $key)
{
	$value = stripslashes($value);	
}

/**
 * Sets the value for a specific column
 * @param array &$colDetails column details (one element of the $column array)
 * @access private
 */
function tNG_prepareValues(&$colDetails) {
	$type2alt = array(
		'CHECKBOX_1_0_TYPE'=>'1',
		'CHECKBOX_-1_0_TYPE'=>'-1',
		'CHECKBOX_YN_TYPE'=>"Y",
		'CHECKBOX_TF_TYPE'=>"t",
	);
	if (isset($colDetails['method']) && isset($colDetails['reference']) && isset($colDetails['type'])) {
		$colValue = tNG_getRealValue($colDetails['method'], $colDetails['reference']);
		switch ($colDetails['type']) {
			case 'CHECKBOX_YN_TYPE':
			case 'CHECKBOX_1_0_TYPE':
			case 'CHECKBOX_-1_0_TYPE':
			case 'CHECKBOX_TF_TYPE':
				$colValue = !isset($colValue) ?  '' : $type2alt[$colDetails['type']];
				break;
			case 'DATE_TYPE':
			case 'DATE_ACCESS_TYPE':
				$colValue = tNG_DynamicData($colValue, null);
				$colValue = KT_formatDate2DB($colValue);
				if (isset($colDetails['default'])) {
					$default = tNG_DynamicData($colDetails['default'], null);
					$colDetails['default'] = KT_formatDate2DB($default);
				}
				break;
		}
	} else {
		$colValue = "";
	}
	$colDetails['value'] =  $colValue;
}

/**
 * Compiles a method and a reference into a value
 * Ex: method=GET and reference=test, return value=$_GET['test']
 * @param string $method The method (GET, POST, etc)
 * @param string $reference The reference (variable name)
 * @return object unknown The compiled value
 *         the return has stripped slashes if necessary
 * @access public
 */
function tNG_getRealValue($method, $reference) {
	$needStrip = false;
	$ret = null;
	switch($method) {
		case 'GET':
			if (isset($_GET[$reference])) {
				$ret = $_GET[$reference];
			}
			$needStrip = true;
			break;
		case 'POST':
			if (isset($_POST[$reference])) {
				$ret = $_POST[$reference];
			}
			$needStrip = true;
			break;
		case 'COOKIE':
			if (isset($_COOKIE[$reference])) {
				$ret = $_COOKIE[$reference];
			}
			$needStrip = true;
			break;
		case 'SESSION':
			if (isset($_SESSION[$reference])) {
				$ret = $_SESSION[$reference];
			}
			break;
		case 'GLOBALS':
			if (isset($GLOBALS[$reference])) {
				$ret = $GLOBALS[$reference];
			}
			break;
		case 'SERVER':
			if (isset($_SERVER[$reference])) {
				$ret = $_SERVER[$reference];
			}
			break;
		case 'FILES':
			if (isset($_FILES[$reference])) {
				$ret = @$_FILES[$reference]['name'];
			}
			break;
		case 'VALUE':
			$ret = $reference;
			break;
		case 'CURRVAL':
			$ret = null;
			break;
		case 'CSV':
			if (isset($GLOBALS['KT_CSV'][$reference])) {
				$ret = $GLOBALS['KT_CSV'][$reference];
			}
			break;
		default:
			die('tNG_getRealValue:<br />Unknown method: '.$method.'.');
			break;
	}
	if ($needStrip && !is_null($ret)) {
		if (get_magic_quotes_gpc() || (isset($GLOBALS['KT_serverModel']) && $GLOBALS['KT_serverModel'] == 'adodb')) {
			if (is_array($ret)) {
				array_walk($ret, 'tNG_stripslashes');	
			} else {
				$ret = stripslashes($ret);	
			}
		}
	}
	return $ret;
}

// Session functions

function tNG_setSessionValabilityPath($tNGinc_dirname) {
	// tNGinc file is 2 levels from the root of the site
	$tNGinc_relPathToRoot = '../../';
	$tNGinc_path = str_replace("\\", "/", $tNGinc_dirname);
	if (substr($tNGinc_path, strlen($tNGinc_path)-1,1) != "/") {   // add trailing /
		$tNGinc_path .= "/";
 	}
	// remove the 2 levels from tNGinc_path to get to the root of the site
	while (strpos($tNGinc_relPathToRoot, '../') === 0) {
		$tNGinc_relPathToRoot = substr($tNGinc_relPathToRoot, 3);
		if ($tNGinc_path != "/") {
			$tNGinc_path = preg_replace("/\/[^\/]*\/[^\/]*$/", '/', $tNGinc_path);
		}
	}
	
	$absPath_running_script = $_SERVER['PATH_TRANSLATED']; 
	$absPath_running_script = str_replace("\\", "/", $absPath_running_script);

	// try to match $tNGinc_path into $absPath_running_script and get the remainings 
	// ( remainings = the relative path of the current file to the root of the site)

	$pos = strpos(strtolower($absPath_running_script), strtolower($tNGinc_path));
	if ($pos === false) {
		$valability_path = "/";
	}
	else {
		// build the relPath_running_script as the remaining after removing $tNGinc_path from $absPath_running_script
		$relPath_running_script = substr($absPath_running_script, $pos + strlen($tNGinc_path));
		
		$url_running_script = $_SERVER['PHP_SELF'];
		// to get valability path must remove $relPath_running_script from $url_running_script
		$pos = strpos(strtolower($url_running_script), strtolower($relPath_running_script));
		if ($pos === false) {
			$valability_path = "/";
		}
		else {
			$valability_path = substr($url_running_script, 0, $pos);
		}
	}
	$parts = explode("/",$valability_path);
	$partsURL = array_map("rawurlencode",$parts);
	$valability_path = implode("/", $partsURL);
	session_set_cookie_params (0, $valability_path);
}



function tNG_generateRandomString($len) {
	//make a seed for the random generator
	list($usec, $sec) = explode(' ', microtime());
	$seed =  (float) $sec + ((float) $usec * 100000);
	//generate a new random value
	srand($seed);
	$newstring = md5(rand());
	if ($len) {
		return substr($newstring,0,$len);
	} else {
		return $newstring;
	}
}


function tNG_encryptString($plain_string) {
	$encrypted_string = md5($plain_string);
	return $encrypted_string;
}

function tNG_activationLogin(&$connection) {
	if (isset($_GET['kt_login_id']) && isset($_GET['kt_login_random'])) {
		// make an instance of the transaction object
		$loginTransaction_activation = new tNG_login($connection);
		// register triggers
		// automatically start the transaction
		$loginTransaction_activation->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "VALUE", "1");

		// add columns
		$loginTransaction_activation->setLoginType('activation');
		$loginTransaction_activation->addColumn("kt_login_id", $GLOBALS['tNG_login_config']['pk_type'] , "GET", "kt_login_id");
		$loginTransaction_activation->addColumn("kt_login_random", "STRING_TYPE", "GET", "kt_login_random");
		 
		$loginTransaction_activation->executeTransaction();
		if (isset($loginTransaction_activation->columns["kt_login_redirect"])) {
			// return already computed redirect page
			return $loginTransaction_activation->getColumnValue("kt_login_redirect");
		}
	}	
	return "";
}


function tNG_cookieLogin(&$connection) {
	if (isset($_SESSION['kt_login_user'])) {
		return;
	}	
	if (isset($_COOKIE['kt_login_id']) && isset($_COOKIE['kt_login_test'])) {
		// make an instance of the transaction object
		$loginTransaction_cookie = new tNG_login($connection);
		// register triggers
		// automatically start the transaction
		$loginTransaction_cookie->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "VALUE", "1");

		// add columns
		$loginTransaction_cookie->setLoginType('cookie');
		$loginTransaction_cookie->addColumn("kt_login_id", $GLOBALS['tNG_login_config']['pk_type'] , "COOKIE", "kt_login_id");
		$loginTransaction_cookie->addColumn("kt_login_test", "STRING_TYPE", "COOKIE", "kt_login_test");
		 
		$loginTransaction_cookie->executeTransaction();
	}
}

function NXT_getResource($resourceName) {
	return KT_getResource($resourceName, 'NXT');
}

?>
