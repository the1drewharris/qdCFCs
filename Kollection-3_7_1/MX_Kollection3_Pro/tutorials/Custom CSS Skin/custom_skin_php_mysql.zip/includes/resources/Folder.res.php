<?php
$res = array(
'PHP_FOLDER_READ_ERR' => 'Error reading folder.',
'PHP_FOLDER_CREATE_ERR' => 'Error creating folder.',
'PHP_FOLDER_DELETE_ERR' => 'Error deleting folder.',
'PHP_FOLDER_READ_ERR_D' => 'Error reading folder: "%s". Permissions not granted.',
'PHP_FOLDER_CREATE_ERR_D' => 'Error creating folder "%s". Permissions not granted.',
'PHP_FOLDER_DELETE_ERR_D' => 'Error deleting folder "%s". Permissions not granted.',
);
?>