<script type="text/javascript">
	$NAV_Text_start = <?php echo ($nav_totalRows == 0)?0:($nav_pageNum*$nav_maxRows + 1) ?>;
</script>
 <?php require ("NAV_Text.inc.php"); ?>
 -
 <?php echo ($nav_totalRows == 0)?0:($nav_pageNum*$nav_maxRows + 1) ?>
 <?php echo NXT_getResource("to"); ?>
 <?php echo min($nav_pageNum*$nav_maxRows + $nav_maxRows, $nav_totalRows) ?>
 <?php echo NXT_getResource("of"); ?>
 <?php echo $nav_totalRows ?>
