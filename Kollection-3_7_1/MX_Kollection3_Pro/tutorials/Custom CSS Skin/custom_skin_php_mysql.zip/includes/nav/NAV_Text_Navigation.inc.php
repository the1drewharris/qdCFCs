<?php require ("NAV_Text.inc.php"); ?>
<div class="KT_textnav clearfix">
  <ul>
		<li class="first">
			<a href="<?php 
				if ($nav_pageNum > 0) {
					printf("%s?pageNum_".$nav_rsName."=%d&totalRows_".$nav_rsName."=%d%s", $nav_currentPage, 0, $nav_totalRows, $nav_queryString); 
				} else {
					if ($nav_showNoLink) {
						echo "javascript: void(0);";
					}
				}?>"><?php echo NXT_getResource("First"); ?></a>
		</li>
		<li class="prev">
				<a href="<?php
				if ($nav_pageNum > 0) {
					printf("%s?pageNum_".$nav_rsName."=%d&totalRows_".$nav_rsName."=%d%s", $nav_currentPage, max(0, $nav_pageNum - 1), $nav_totalRows, $nav_queryString);
				} else {
					if ($nav_showNoLink) {
						echo "javascript: void(0);";
					}
				}
				?>"><?php echo NXT_getResource("Previous"); ?></a>
		</li>
		<li class="next">
			<a href="<?php 
				if ($nav_pageNum < $nav_totalPages) {
					printf("%s?pageNum_".$nav_rsName."=%d&totalRows_".$nav_rsName."=%d%s", $nav_currentPage, min($nav_totalPages, $nav_pageNum + 1), $nav_totalRows, $nav_queryString); 
				} else {
					if ($nav_showNoLink) {
						echo "javascript: void(0);";
					}
				}?>"><?php echo NXT_getResource("Next"); ?></a>
		</li>
		<li class="last">
			<a href="<?php
				if ($nav_pageNum < $nav_totalPages) {
					printf("%s?pageNum_".$nav_rsName."=%d&totalRows_".$nav_rsName."=%d%s", $nav_currentPage, $nav_totalPages, $nav_totalRows, $nav_queryString); 
				} else {
					if ($nav_showNoLink) {
						echo "javascript: void(0);";
					}
				}?>"><?php echo NXT_getResource("Last"); ?></a>
		</li>
  </ul>
</div>
