<?php
	class NAV_Regular {
		var $navName = "";
		var $rsName = "";
		var $showNoLink = "";

		function NAV_Regular($navName, $rsName, $relPath, $currentPage, $showNoLink, $maxRows) {
			$this->navName = $navName;
			$this->rsName = $rsName;
			$this->showNoLink = $showNoLink;

			$GLOBALS['nav_relPath'] = $relPath;
			$GLOBALS['nav_currentPage'] = $currentPage;

			KT_session_start();
			$_SESSION["default_max_rows_" . $navName] = $maxRows;
			
			if (isset($_GET["show_all_" . $this->navName])) {
				$_SESSION["max_rows_" . $navName] = 10000;
			} else {
				$_SESSION["max_rows_" . $navName] = $maxRows;
			}
		}
		
		function checkTotalRows() {
			if($GLOBALS['startRow_'.$this->rsName]  >= $GLOBALS['totalRows_'.$this->rsName]) {
				$KT_url = $_SERVER['PHP_SELF']; 
				$pageNum = $GLOBALS['pageNum_'.$this->rsName];
				$maxRows = $GLOBALS['maxRows_'.$this->rsName];
				$totalRows = $GLOBALS['totalRows_'.$this->rsName];
				
				$pageNum = max( (int)(($totalRows-1) / $maxRows),0);
				
				if($pageNum > 0) {
					$KT_url = KT_addReplaceParam($KT_url,'pageNum_'.$this->rsName,$pageNum);
				} else {
					$KT_url = KT_addReplaceParam($KT_url,'pageNum_'.$this->rsName);
				}
				if ($totalRows != 0 && isset($_GET['pageNum_'.$this->rsName])) {
					KT_redir($KT_url);
				}					
			} elseif ($GLOBALS['startRow_'.$this->rsName] <0) {
				$KT_url = $_SERVER['PHP_SELF']; 
				$KT_url = KT_addReplaceParam($KT_url,'pageNum_'.$this->rsName);
				KT_redir($KT_url);
			}
		
		}

		function Prepare() {

			$queryString = $_SERVER['QUERY_STRING'];
			$queryString = KT_addReplaceParam($queryString, 'pageNum_'.$this->rsName);
			$queryString = KT_addReplaceParam($queryString, 'totalRows_'.$this->rsName);
			if ($queryString!='') {
				$queryString = '&'.$queryString; 
			}

			$GLOBALS['nav_maxRows']     = $GLOBALS['maxRows_'    . $this->rsName];
			$GLOBALS['nav_pageNum']     = $GLOBALS['pageNum_'    . $this->rsName];
			$GLOBALS['nav_totalPages']  = $GLOBALS['totalPages_' . $this->rsName];
			$GLOBALS['nav_totalRows']   = $GLOBALS['totalRows_'  . $this->rsName];

			$GLOBALS['nav_rsName']     = $this->rsName;
			$GLOBALS['nav_showNoLink']  = $this->showNoLink;
			$GLOBALS['nav_queryString'] = $queryString;

		}

		function getShowAllLink() {

			$show_all_reference = "show_all_" . $this->navName;

			if (isset($_GET[$show_all_reference])) {
				$url = KT_addReplaceParam($_SERVER['REQUEST_URI'], $show_all_reference);
			} else {
				$url = KT_addReplaceParam($_SERVER['REQUEST_URI'], $show_all_reference, "1");
			}
			$url = KT_addReplaceParam($url, 'pageNum_' . $this->rsName);
			$url = KT_addReplaceParam($url, 'totalRows_' . $this->rsName);

			return $url;
		}

	}

?>
