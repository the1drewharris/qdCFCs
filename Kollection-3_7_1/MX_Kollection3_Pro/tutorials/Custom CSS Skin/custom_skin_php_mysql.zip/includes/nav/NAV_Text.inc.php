<?php
$nav_rsName = $GLOBALS['nav_rsName'];
$nav_queryString = $GLOBALS['nav_queryString'];
$nav_maxRows = $GLOBALS['nav_maxRows'];
$nav_pageNum = $GLOBALS['nav_pageNum'];
$nav_totalPages = $GLOBALS['nav_totalPages'];
$nav_currentPage = $GLOBALS['nav_currentPage'];
$nav_showNoLink = $GLOBALS['nav_showNoLink'];
$nav_totalRows = $GLOBALS['nav_totalRows'];
?>
