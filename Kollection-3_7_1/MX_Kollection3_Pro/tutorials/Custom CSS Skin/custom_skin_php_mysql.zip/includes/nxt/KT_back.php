<?php
if (isset($_GET['KT_back'])) {

	$tmp = KT_addReplaceParam($_SERVER['REQUEST_URI'], 'KT_back');

	if (isset($_SERVER['HTTP_REFERER'])) {
		$backURL = $_SERVER['HTTP_REFERER'];
	} else {
		$backURL = $tmp;
	}

	KT_session_start();
	if (!isset($_SESSION['KT_backArr'])) {
		$_SESSION['KT_backArr'] = array();
	}
	$backURL = KT_addReplaceParam($backURL, '/^totalRows_.*$/i');
	array_push($_SESSION['KT_backArr'], $backURL);

	if (isset($_POST['KT_Delete1'])) {
		?>
<html>
<head>
</head>
	<body>
		<form action="<?php echo ($tmp); ?>" method="POST">
		<?php
		foreach($_POST as $key => $value) {
			if ($key == 'KT_Delete1' || strpos($key, 'kt_pk_') === 0) {
				if (get_magic_quotes_gpc()) {
					$value = stripslashes($value);
				}
		?>
			<input type="hidden" name="<?php echo $key; ?>" value="<?php echo KT_escapeAttribute($value); ?>" />
		<?php
			}
		}
		?>
		</form>
		<script>
			document.forms[0].submit();
		</script>
	</body>
</html>
		<?php
	} else {
		KT_redir($tmp);
	}
	exit;
}
?>
