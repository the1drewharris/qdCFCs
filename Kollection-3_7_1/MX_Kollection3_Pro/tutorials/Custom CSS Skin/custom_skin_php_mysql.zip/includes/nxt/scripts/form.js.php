<?php
	include_once(dirname(realpath(__FILE__)) . '/../../common/lib/resources/KT_Resources.php');
	$d = 'NXT';
?>
//Javascript UniVAL Resources
NXT_Messages = {};
NXT_Messages['are_you_sure_move'] = '<?php echo KT_escapeJS(KT_getResource('ARE_YOU_SURE_MOVE', $d)); ?>';
