<?php //PHP ADODB document - made with PHAkt 3.0.9?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p></p>
<p>
<a href="view_order.php">View order</a> <a href="clear_order.php">Clear order</a> <a href="complete_order.php">Complete order</a> Logout 
</p>
</body>
</html>
