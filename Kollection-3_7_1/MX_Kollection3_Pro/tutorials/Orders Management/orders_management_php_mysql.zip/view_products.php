<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>

<body>
<p></p>
<p>
<a href="view_order.php">View order</a> <a href="clear_order.php">Clear order</a> <a href="complete_order.php">Complete order</a> Logout 
</p>
</body>
</html>
