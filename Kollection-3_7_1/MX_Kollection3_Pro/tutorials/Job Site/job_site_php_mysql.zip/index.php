<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>

<body>
<h2>Welcome to our site!</h2>
<hr>
<p>If you are already registred to our site, please login <a href="login.php">here</a>.</p>
<p>If you forgot your password, click <a href="forgot.php">here</a>.</p>
<p>If you are a non-registered <strong>company</strong> please register <a href="register_company.php">here</a>.</p>
<p>If you are a non-registered <strong>user</strong> please register <a href="register_user.php">here</a>. </p>
<p>&nbsp;</p>
</body>
</html>
