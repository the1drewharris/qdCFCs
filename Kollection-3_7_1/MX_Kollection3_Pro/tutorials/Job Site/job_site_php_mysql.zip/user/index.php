<?php require_once('../Connections/connJobs.php'); ?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Make unified connection variable
$conn_connJobs = new KT_connection($connJobs, $database_connJobs);

//Start Restrict Access to Page
$restrict = new tNG_RestrictAccess($conn_connJobs, "../");
//Grand Levels: Level
$restrict->addLevel("0");
$restrict->Execute();
//End Restrict Access to Page

//Start log out user
  $logout = new tNG_Logout();
  $logout->setLogoutType("link");
  $logout->Execute();
//End log out user
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Applicant area</title>
</head>

<body>
<h2>Applicant area </h2>
<hr>
<p><a href="create_resume.php?idusr_rsm=<?php echo $_SESSION['KT_login_id']; ?>">Create resume</a></p>
<p><a href="cover.php">Write cover letter</a></p>
<p><a href="view_jobs.php">View job ads</a></p>
<p><a href="view_subscription.php">View subscriptions</a></p>
<p><a href="search.php">Search for jobs</a></p>
<a href="<?php echo $logout->getLogoutLink(); ?>">Logout</a>
</body>
</html>
