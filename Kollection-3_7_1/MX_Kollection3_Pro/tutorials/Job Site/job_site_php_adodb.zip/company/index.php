<?php //PHP ADODB document - made with PHAkt 2.8.3?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h2>Company area </h2>
<hr>
<p><a href="com_details.php">Fill in company details</a></p>
<p><a href="post_job.php">Post job ad</a></p>
<p><a href="view_jobs.php">View my jobs</a></p>

</body>
</html>
