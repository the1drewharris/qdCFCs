<?php //PHP ADODB document - made with PHAkt 2.8.3?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h2>Welcome to our site!</h2>
<hr>
<p>If you are already registred to our site, please login <a href="login.php">here</a>.</p>
<p>If you forgot your password, click <a href="forgot.php">here</a>.</p>
<p>If you are a non-registered <strong>company</strong> please register <a href="register_company.php">here</a>.</p>
<p>If you are a non-registered <strong>user</strong> please register <a href="register_user.php">here</a>. </p>
<p>&nbsp;</p>

</body>
</html>
