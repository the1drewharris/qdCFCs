<?php //PHP ADODB document - made with PHAkt 2.8.3?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h2>Applicant area </h2>
<hr>
<p><a href="create_resume.php">Create resume</a></p>
<p><a href="cover.php">Write cover letter</a></p>
<p><a href="view_jobs.php">View job ads</a></p>
<p><a href="view_subscription.php">View subscriptions</a></p>
<p><a href="search.php">Search for jobs</a></p>
</body>
</html>
