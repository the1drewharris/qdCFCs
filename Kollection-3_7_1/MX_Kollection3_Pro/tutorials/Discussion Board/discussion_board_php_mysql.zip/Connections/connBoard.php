<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_connBoard = "localhost";
$database_connBoard = "discussion_board";
$username_connBoard = "username";
$password_connBoard = "password";
$connBoard = mysql_pconnect($hostname_connBoard, $username_connBoard, $password_connBoard) or die(mysql_error());
?>