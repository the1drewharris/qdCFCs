<?php echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>

<body>
<table width="95%" border="0" cellspacing="1" cellpadding="1">
  <tr bgcolor="#b6c7e5">
    <td width="79%">Welcome to the Discussion Board </td>
    <td width="21%"> <a href="login.php">Login</a> | <a href="register.php">Register</a></td>
  </tr>
  <tr>
    <td height="23" colspan="2">&nbsp;</td>
  </tr>
  <tr bgcolor="#b6c7e5">
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
</body>
</html>
