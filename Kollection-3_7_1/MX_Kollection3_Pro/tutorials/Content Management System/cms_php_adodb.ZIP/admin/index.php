<?php //PHP ADODB document - made with PHAkt 2.15.2?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h2>Welcome to the Content Management Administrative area
</h2>
<p><a href="list_art.php">View article list</a></p>
<p><a href="detail_art.php">Add article</a></p>
<p><a href="../index.php">Back to front-end </a> </p>
</body>
</html>
