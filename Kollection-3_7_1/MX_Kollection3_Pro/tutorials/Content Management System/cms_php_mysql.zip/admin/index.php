<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>

<body>
<h2>Welcome to the Content Management Administrative area</h2>
<p><a href="list_art.php">View article list</a></p>
<p><a href="detail_art.php">Add article</a></p>
<p><a href="../index.php">Back to front-end</a>  </p>
</body>
</html>
