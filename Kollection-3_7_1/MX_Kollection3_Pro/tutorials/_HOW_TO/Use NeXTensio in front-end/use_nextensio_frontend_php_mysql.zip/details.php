<?php require_once('Connections/connList.php'); ?>
<?php
$colname_rsDetails = "-1";
if (isset($_GET['id_prd'])) {
  $colname_rsDetails = (get_magic_quotes_gpc()) ? $_GET['id_prd'] : addslashes($_GET['id_prd']);
}
mysql_select_db($database_connList, $connList);
$query_rsDetails = sprintf("SELECT * FROM products_prd WHERE id_prd = %s", $colname_rsDetails);
$rsDetails = mysql_query($query_rsDetails, $connList) or die(mysql_error());
$row_rsDetails = mysql_fetch_assoc($rsDetails);
$totalRows_rsDetails = mysql_num_rows($rsDetails);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>

<body>
<h3><?php echo $row_rsDetails['name_prd']; ?> - $<?php echo $row_rsDetails['price_prd']; ?>
</h3>
<p><?php echo $row_rsDetails['description_prd']; ?></p>
</body>
</html>
<?php
mysql_free_result($rsDetails);
?>
