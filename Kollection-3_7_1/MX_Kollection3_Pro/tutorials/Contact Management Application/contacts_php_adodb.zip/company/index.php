<?php
//Connection statement
require_once('../Connections/connContacts.php');

// begin Recordset
$query_Recordset1 = "SELECT * FROM company_com";
$Recordset1 = $connContacts->SelectLimit($query_Recordset1) or die($connContacts->ErrorMsg());
$totalRows_Recordset1 = $Recordset1->RecordCount();
// end Recordset
 //PHP ADODB document - made with PHAkt 2.8.2?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>

<body>
<p>Companies:</p>
<table border="1">
  <tr>
    <td>id_com</td>
    <td>name_com</td>
    <td>address_com</td>
    <td>&nbsp;</td>
  </tr>
 <?php
  while (!$Recordset1->EOF) {
?>
<tr>
<td><?php echo $Recordset1->Fields('id_com'); ?></td>
<td><?php echo $Recordset1->Fields('name_com'); ?></td>
<td><?php echo $Recordset1->Fields('address_com'); ?></td>
<td><a href="update.php?id_com=<?php echo $Recordset1->Fields('id_com'); ?>">Update</a> <a href="delete.php?id_com=<?php echo $Recordset1->Fields('id_com'); ?>">Delete</a> </td>
</tr>
<?php
    $Recordset1->MoveNext();
  }
?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><a href="insert.php">New</a></td>
  </tr>
</table>
</body>
</html>
<?php
$Recordset1->Close();
?>
